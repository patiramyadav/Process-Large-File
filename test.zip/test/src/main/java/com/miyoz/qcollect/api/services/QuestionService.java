/**
 *
 */
package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.interfaces.impl.SearchParams;
import com.miyoz.qcollect.api.models.notifications.ApprovalNotification;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface QuestionService extends CommonService<String, Question> {
    Page<Question> findAll(Pageable pageable);
    Page<Question> findAll(Pageable pageable, String keyword);
    Page<Question> findAllForUser(Pageable pageable, String userId);
    Page<Question> findAllForUser(Pageable pageable, String userId, String keyword);
    Page<Question> findAllForLevel(Pageable pageable, String level);

    List<Question> updateApprovals();
    List<Question> updateContentType();

    Question updateQuestion(Question question);

    Question findQuestion(SearchParams searchParams);

    Page<ApprovalNotification> findApprovalsForUser(Pageable pageable, String userId);
}
