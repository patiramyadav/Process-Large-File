package com.miyoz.qcollect.api.repositories;

import com.miyoz.qcollect.api.models.impl.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.Date;
import java.util.List;

public interface UserRepository extends MongoRepository<User, String>, BaseRepository {

    List<User> findByRole(String role);

    User findByEmail(String email);

    User findByIdAndEmail(String id, String email);

    User findByIdAndEmailVerifiedAndActive(String id, boolean emailVerified, boolean active);

    @Query("{$and: [{dateCreated: {$lte: ?0}}, {emailVerified: ?1}]}")
    List<User> findByVerificationStatus(Date dateBefore, boolean emailVerified);
}