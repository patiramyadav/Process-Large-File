package com.miyoz.qcollect.api.models.types;

public enum RateType {
    HOURLY,
    MONTHLY,
    YEARLY,
    PER_COURSE,
    VOLUNTARILY
}
