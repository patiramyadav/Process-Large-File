package com.miyoz.qcollect.api.models.types;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.models.common.ErrorCodes;

/**
 * Created by Yogen on 10/28/2017.
 */
public enum LevelType {
    SCHOOL("SSE"),
    PLUS_ONE("10+1"),
    PLUS_TWO("10+2"),
    BACHELORS("Bachelors"),
    MASTERS("Masters");

    private final String value;

    LevelType(String value) {
        this.value = value;
    }

    @JsonCreator
    public static LevelType forValue(final String value) {
        for (LevelType levelType : values()) {
            if (levelType.value.equalsIgnoreCase(value)) {
                return levelType;
            }
        }
        throw new DataException(ErrorCodes.EXC400.toString(), null);
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }
}
