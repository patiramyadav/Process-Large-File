package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface MessageService {
    void saveMessage(Message message);

    Page<Message> getAllMessages(Pageable pageable, String email);
}
