package com.miyoz.qcollect.api.models.common;

public enum ErrorCodes {
    EXC400,
    EXC401,
    EXC403,
    EXC404,
    EXC409,
    EXC500,
    EXC501
}
