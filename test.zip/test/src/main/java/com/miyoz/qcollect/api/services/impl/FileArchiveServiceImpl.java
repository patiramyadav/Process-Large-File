package com.miyoz.qcollect.api.services.impl;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.miyoz.qcollect.api.exceptions.ServiceException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Document;
import com.miyoz.qcollect.api.models.impl.DocumentInfo;
import com.miyoz.qcollect.api.services.FileArchiveService;
import com.miyoz.qcollect.api.utils.Number;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.time.Instant;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class FileArchiveServiceImpl implements FileArchiveService {
    private final AmazonS3Client s3Client;

    private static final String S3_BUCKET_NAME = "miyoz-data";

    @Override
    public DocumentInfo saveFilesToS3(Document document) {
        try {
            File fileToUpload = convertFromMultiPart(document.getFile());
            String key = "q-collect/" + Instant.now().getEpochSecond() + "_" + fileToUpload.getName();

            /* save file */
            s3Client.putObject(new PutObjectRequest(S3_BUCKET_NAME, key, fileToUpload));

            /* get signed URL (valid for one year) */
            GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(S3_BUCKET_NAME, key);
            generatePresignedUrlRequest.setMethod(HttpMethod.GET);
            generatePresignedUrlRequest.setExpiration(DateTime.now().plusDays(Number.SEVEN).toDate());

            URL signedUrl = s3Client.generatePresignedUrl(generatePresignedUrlRequest);

            return new DocumentInfo(null, document.getDocName(), key, signedUrl.toString());
        } catch (Exception ex) {
            log.error(ex.getMessage());
            throw new ServiceException(ErrorCodes.EXC500.toString(), new Error(ErrorCodes.EXC500.toString(), "document", "An error occurred saving file to S3"));
        }
    }

    private File convertFromMultiPart(MultipartFile file) throws IOException {
        File convFile = new File(file.getOriginalFilename());
        convFile.createNewFile();
        FileOutputStream fos = new FileOutputStream(convFile);
        fos.write(file.getBytes());
        fos.close();
        return convFile;
    }

    @Override
    public void deleteFilesFromS3(String s3key) {
        try {
            s3Client.deleteObject(new DeleteObjectRequest(S3_BUCKET_NAME, s3key));
        } catch (Exception ex) {
            log.error(ex.getMessage());
            throw new ServiceException(ErrorCodes.EXC500.toString(), new Error(ErrorCodes.EXC500.toString(), "document", "An error occurred deleting file from S3"));
        }

    }
}
