package com.miyoz.qcollect.api.models.types;

/**
 * Created by Yogen on 11/30/2017.
 */
public enum ProgramType {
    BBA,
    BBA_TT,
    BBA_BI,
    BBS,
    BIM,
    BIT,
    BCA,
    BHM,
    BTTM,
    MBS,
    MBM,
    MCIS,
    MBA,
    MA,
    MEd,
    MTTM,
    MHM,
    BA,
    BEd,
    BSW,
    BscCSIT,
    Bsc,
    BBM,
    BCIS,
    SSE,
    INTER
}
