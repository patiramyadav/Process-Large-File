package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miyoz.qcollect.api.models.Model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Transient;

import javax.validation.constraints.Size;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class Coordinate extends Model<String> {

    @Transient
    @JsonIgnore
    private String id;

    @Size(min = 2, max = 2)
    private List<Double> coordinates;

    private String type;

}
