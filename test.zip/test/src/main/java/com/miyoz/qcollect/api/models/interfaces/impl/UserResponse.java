package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.dtos.UserDto;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class UserResponse extends ResourceSupport {
    private List<UserDto> users;
}
