package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.miyoz.qcollect.api.models.Model;
import com.miyoz.qcollect.api.utils.Number;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;


@Getter
@Setter
@ToString
@Document(collection = "message")
public class Message extends Model<String> {
    @Id
    private String id;

    @JsonProperty("name")
    @NotNull
    @NotEmpty
    @Field("sender_name")
    private String senderName;

    @JsonProperty("email")
    @NotNull
    @NotEmpty
    @Email
    @Field("sender_email")
    private String senderEmail;

    @JsonProperty("message")
    @NotNull
    @NotEmpty
    @Size(min = Number.TEN, max = Number.FIVE_HUNDRED)
    private String content;

    @Field("date_created")
    private Date dateCreated;

    private String subject;

    private boolean read;

    private String sentToEmail;
}
