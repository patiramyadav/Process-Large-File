package com.miyoz.qcollect.api.controllers.impl;

import com.google.common.base.Strings;
import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.exceptions.InvalidInputException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Article;
import com.miyoz.qcollect.api.models.impl.Comment;
import com.miyoz.qcollect.api.models.interfaces.impl.ArticleResponse;
import com.miyoz.qcollect.api.services.ArticleService;
import com.miyoz.qcollect.api.services.CommentService;
import com.miyoz.qcollect.api.utils.QCollectAuth;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Collections;
import java.util.List;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class ArticleController implements BaseController<Article> {

    private final ArticleService articleService;
    private final CommentService commentService;

    private final ApplicationEventPublisher applicationEventPublisher;

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PostMapping(value = "/articles", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Article> createArticle(@Valid @RequestBody Article article,
                                                 BindingResult result,
                                                 @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                 @RequestHeader("Authorization") final String authorization) {
        if (result.hasErrors()) {
            log.debug("Invalid article sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }

        Article articleCreated = this.articleService.create(article);
        return new ResponseEntity<>(articleCreated, HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @DeleteMapping(value = "/articles/{id}")
    public ResponseEntity<?> deleteArticle(@ApiParam(value = "Article Id", required = true) @PathVariable("id") String id,
                                           @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                           @RequestHeader("Authorization") final String authorization) {

        this.articleService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PutMapping(value = "/articles", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<ArticleResponse> updateArticle(@Valid @RequestBody Article article,
                                                         BindingResult result,
                                                         @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                         @RequestHeader("Authorization") final String authorization) {
        if (Strings.isNullOrEmpty(article.getId())) {
            result.rejectValue("id", "NotNull", "Id is required.");
        }
        if (result.hasErrors()) {
            log.debug("Invalid article sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }

        Article updatedArticle = this.articleService.update(article);


        // send notification if article is approved
        /*if (!article.isVerified() && updatedArticle.isVerified()) {
            this.applicationEventPublisher.publishEvent(new OnAddSyllabusEvent(updatedArticle));
        }*/

        ArticleResponse articleResponse = new ArticleResponse(Collections.singletonList(updatedArticle));
        articleResponse.add(linkTo(methodOn(ArticleController.class).updateArticle(article, result, authorization)).withSelfRel());
        return new ResponseEntity<>(articleResponse, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @GetMapping(value = "/articles", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Page<Article>> getArticles(Pageable pageable,
                                                     @ApiParam(value = "User Id to article search for", required = false)
                                                     @RequestParam(value = "userId", required = false) final String userId,
                                                     @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                     @RequestHeader("Authorization") final String authorization) {
        final Page<Article> articlePage;
        if (!Strings.isNullOrEmpty(userId)) {
            articlePage = this.articleService.findArticlesForUser(pageable, userId);
        } else if (Strings.isNullOrEmpty(userId) && QCollectAuth.isRoleAdmin()) {
            articlePage = this.articleService.findAll(pageable);
        } else {
            throw new InvalidInputException(ErrorCodes.EXC400.toString(), new Error(ErrorCodes.EXC400.toString(), "userId", "Role or Id mismatched."));
        }
        return new ResponseEntity<>(articlePage, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PostMapping(value = "/articles/{articleId}/comments", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Comment> createComment(@Valid @RequestBody Comment comment, BindingResult result,
                                                 @ApiParam(value = "Article Id", required = true)
                                                 @PathVariable("articleId") String articleId,
                                                 @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                 @RequestHeader("Authorization") final String authorization) {
        if (result.hasErrors()) {
            log.debug("Invalid Article sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }
        Comment createdComment = this.commentService.create(comment);
        return new ResponseEntity<>(createdComment, HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PutMapping(value = "/articles/{articleId}/comments", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Comment> updateComment(@Valid @RequestBody Comment comment, BindingResult result,
                                                 @ApiParam(value = "Article Id", required = true)
                                                 @PathVariable("articleId") String articleId,
                                                 @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                 @RequestHeader("Authorization") final String authorization) {

        if (Strings.isNullOrEmpty(comment.getId())) {
            result.rejectValue("id", "NotNull", "Id is required.");
        }
        if (result.hasErrors()) {
            log.debug("Invalid Article sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }

        Comment updatedComment = this.commentService.update(comment);
        return new ResponseEntity<>(updatedComment, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @DeleteMapping("/articles/{articleId}/comments/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable("articleId") String articleId,
                                           @PathVariable("commentId") String commentId,
                                           @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                           @RequestHeader("Authorization") final String authorization) {
        if (!this.articleService.findOne(articleId).isPresent()) {
            throw new NotFoundException(ErrorCodes.EXC404.toString(), null);
        }


        this.commentService.delete(commentId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @GetMapping(value = "/articles/{articleId}/comments", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<List<Comment>> getComments(@ApiParam(value = "Article Id", required = true) @PathVariable("articleId") String articleId, @ApiParam(value = "Token with format 'Bearer Token'", required = true)
    @RequestHeader("Authorization") final String authorization) {
        List<Comment> comments = this.commentService.findByQuestionId(articleId);
        return new ResponseEntity<>(comments, HttpStatus.OK);
    }

}
