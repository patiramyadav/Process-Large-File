package com.miyoz.qcollect.api.services.impl;

import com.google.common.base.Strings;
import com.miyoz.qcollect.api.models.impl.Message;
import com.miyoz.qcollect.api.repositories.MessageRepository;
import com.miyoz.qcollect.api.services.MessageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Objects;


@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class MessageServiceImpl implements MessageService {
    public static final String Q_COLLECT_EMAIL = "qcollect@miyozinc.com";

    private final MessageRepository messageRepository;

    @Override
    public void saveMessage(Message message) {
        message.setDateCreated(new Date());
        message.setRead(false);

        if (Strings.isNullOrEmpty(message.getSentToEmail())) {
            message.setSentToEmail(Q_COLLECT_EMAIL);
        }
        this.messageRepository.save(message);
    }

    @Override
    public Page<Message> getAllMessages(Pageable pageable, String email) {
        Sort sort = pageable.getSort();
        if (Objects.isNull(sort)) {
            sort = new Sort(Sort.Direction.DESC, "dateCreated");
        }
        Pageable pageableReq = new PageRequest(pageable.getPageNumber(), pageable.getPageSize(), sort);
        return messageRepository.findBySentToEmail(pageableReq, email);
    }
}
