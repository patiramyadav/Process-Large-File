package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miyoz.qcollect.api.models.Model;
import com.miyoz.qcollect.api.models.types.RateType;
import com.miyoz.qcollect.api.validators.enumValidator.ValidEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Transient;

@Getter
@Setter
@ToString
public class Rate extends Model<String> {
    @Transient
    @JsonIgnore
    private String id;

    @ValidEnum(enumClass = RateType.class)
    private String rateType;

    private double amount;

}
