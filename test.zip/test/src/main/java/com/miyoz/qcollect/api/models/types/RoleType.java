package com.miyoz.qcollect.api.models.types;

/**
 * @author Yogen
 */
public enum RoleType {
    ROLE_SUPER_ADMIN,
    ROLE_ADMIN,
    ROLE_CONTRIBUTOR,
    ROLE_VIEWER
}
