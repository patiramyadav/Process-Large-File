package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.interfaces.BaseRequest;
import com.miyoz.qcollect.api.models.types.RoleType;
import com.miyoz.qcollect.api.utils.Number;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Getter
@Setter
@ToString
public class UserRequest implements BaseRequest {

    @NotEmpty
    @NotNull
    private String firstName;

    @NotEmpty
    @NotNull
    private String lastName;

    @Email
    @NotEmpty
    private String email;

    @NotEmpty
    @NotNull
    @Size(min = Number.SIX, max = Number.TEN)
    private String password;

    @NotNull
    private RoleType role;

    private String photoUrl;
}
