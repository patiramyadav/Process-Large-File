package com.miyoz.qcollect.api.controllers.impl;

import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Message;
import com.miyoz.qcollect.api.services.MessageService;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class MessageController implements BaseController<Message> {

    private final MessageService messageService;

    @PostMapping(value = "/messages", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> createMessage(@Valid @RequestBody Message message,
                                           BindingResult result) {
        if (result.hasErrors()) {
            log.debug("Invalid message is sent.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }
        this.messageService.saveMessage(message);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN')")
    @GetMapping(value = "/messages-internal", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Page<Message>> getMessages(Pageable pageable,
                                                     @ApiParam(value = "Email to retrive messages", required = true)
                                                     @RequestParam("email") String email,
                                                     @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                     @RequestHeader("Authorization") final String authorization) {
        Page<Message> messages = this.messageService.getAllMessages(pageable, email);
        return new ResponseEntity<>(messages, HttpStatus.OK);
    }
}
