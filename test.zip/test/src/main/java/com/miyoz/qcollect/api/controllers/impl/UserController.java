package com.miyoz.qcollect.api.controllers.impl;

import com.google.common.base.Strings;
import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.mappers.UserMapper;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.interfaces.impl.GenericResponse;
import com.miyoz.qcollect.api.models.interfaces.impl.PasswordChangeRequest;
import com.miyoz.qcollect.api.models.interfaces.impl.UserResponse;
import com.miyoz.qcollect.api.models.types.RoleType;
import com.miyoz.qcollect.api.services.UserService;
import com.miyoz.qcollect.api.services.registration.OnRegistrationCompleteEvent;
import com.miyoz.qcollect.api.validators.RoleValidator;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
@RestController
public class UserController implements BaseController<User> {
    private final UserService userService;

    private final RoleValidator roleValidator;

    private final BCryptPasswordEncoder passwordEncoder;

    private final ApplicationEventPublisher applicationEventPublisher;

    @Value("${jwt.secret}")
    private String secret;

    @GetMapping(value = "/users/{userId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<UserResponse> getUser(
            @ApiParam(value = "User Id as path variable", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
            @RequestHeader("Authorization") final String authorization) {
        Optional<User> userOptional = userService.findOne(userId);
        return userOptional.map(user -> {
            final UserResponse userResponse = new UserResponse(Collections.singletonList(UserMapper.mapToDto(user)));
            userResponse.add(linkTo(methodOn(UserController.class).getUser(userId, authorization)).withSelfRel());
            return new ResponseEntity<>(userResponse, HttpStatus.OK);
        }).orElseThrow(() -> new NotFoundException(ErrorCodes.EXC404.toString(), null));
    }

    /*This is for ROLE_CONTRIBUTOR role*/
    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN')")
    @GetMapping(value = "/users", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<UserResponse> getAllUserByRole(
            @ApiParam(value = "Role name", required = false) @RequestParam(value = "role", required = false) String role,
            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
            @RequestHeader("Authorization") final String authorization) {
        List<User> users;
        if (RoleType.ROLE_CONTRIBUTOR.toString().equalsIgnoreCase(role)) {
            users = userService.findUserByRole(RoleType.ROLE_CONTRIBUTOR.toString());
        } else {
            users = userService.findUserByRole(RoleType.ROLE_VIEWER.toString());
        }
        final UserResponse userResponse = new UserResponse(UserMapper.mapToListDto(users));
        userResponse.add(linkTo(methodOn(UserController.class).getAllUserByRole(role, authorization)).withSelfRel());
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }

    @PreAuthorize("isAuthenticated()")
    @DeleteMapping(value = "/users/{userId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> deleteUser(@ApiParam(value = "User Id as path variable", required = true)
                                        @PathVariable("userId") String userId,
                                        @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                        @RequestHeader("Authorization") final String authorization) {
        this.userService.delete(userId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("isAuthenticated()")
    @PutMapping(value = "/users/changePassword", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<GenericResponse> updatePassword(@RequestBody @Valid final PasswordChangeRequest passwordResetRequest,
                                                          BindingResult result,
                                                          @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                          @RequestHeader("Authorization") final String authorization) {
        if (passwordResetRequest.getPassword() != null && !passwordResetRequest.getPassword().equals(passwordResetRequest.getConfirmPassword())) {
            result.rejectValue("password", "Invalid", "Password didn't match.");
        }
        if (result.hasErrors()) {
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }

        User user = this.userService.findUserByEmailAndPassword(passwordResetRequest.getEmail(), passwordResetRequest.getOldPassword());
        user.setPassword(this.passwordEncoder.encode(passwordResetRequest.getPassword()));
        this.userService.updateUserWithPassword(user);

        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("isAuthenticated()")
    @PutMapping(value = "/users", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<UserResponse> updateUser(@ApiParam(value = "Request Body for User", required = true) @Valid @RequestBody User user,
                                                   BindingResult bindingResult,
                                                   @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                   @RequestHeader("Authorization") final String authorization) {
        if (Strings.isNullOrEmpty(user.getId())) {
            bindingResult.rejectValue("id", "NotNull", "Id is required.");
        }
        if (bindingResult.hasErrors()) {
            throw new DataException(ErrorCodes.EXC400.toString(), bindingResult);
        }

        this.roleValidator.validateRole(user.getRole());

        final User userUpdated = this.userService.update(user);
        final UserResponse userResponse = new UserResponse(Collections.singletonList(UserMapper.mapToDto(userUpdated)));
        userResponse.add(linkTo(methodOn(UserController.class).updateUser(user, bindingResult, authorization)).withSelfRel());
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }

    /*This is for super admin role to admins*/
    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN')")
    @PostMapping(value = "/users", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<UserResponse> createUser(@ApiParam(value = "Request Body for User", required = true) @Valid @RequestBody User user,
                                                   BindingResult bindingResult,
                                                   @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                   @RequestHeader("Authorization") final String authorization) {

        if (bindingResult.hasErrors()) {
            throw new DataException(ErrorCodes.EXC400.toString(), bindingResult);
        }
        final String password = user.getPassword();
        user.setPassword(this.passwordEncoder.encode(password));
        user.setDateCreated(new Date());
        final User userCreated = this.userService.create(user);
        userCreated.setPassword(password);

        // send an email
        this.applicationEventPublisher.publishEvent(new OnRegistrationCompleteEvent(userCreated));

        final UserResponse userResponse = new UserResponse(Collections.singletonList(UserMapper.mapToDto(userCreated)));
        userResponse.add(linkTo(methodOn(UserController.class).createUser(user, bindingResult, authorization)).withSelfRel());
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }

    /*This is for SUPER_ADMIN_ROLE role*/
    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN')")
    @GetMapping(value = "/users/admins", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<UserResponse> getAllAdmins(@ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                     @RequestHeader("Authorization") final String authorization) {
        final List<User> users = this.userService.findUserByRole(RoleType.ROLE_ADMIN.toString());
        final UserResponse userResponse = new UserResponse(UserMapper.mapToListDto(users));
        userResponse.add(linkTo(methodOn(UserController.class).getAllAdmins(authorization)).withSelfRel());
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }
}
