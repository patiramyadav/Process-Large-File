package com.miyoz.qcollect.api.models.impl;

import com.miyoz.qcollect.api.models.Model;
import com.miyoz.qcollect.api.models.types.ContentType;
import com.miyoz.qcollect.api.utils.Number;
import com.miyoz.qcollect.api.validators.enumValidator.ValidEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.TextIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@ToString
@Document(collection = "article")
public class Article extends Model<String> {

    @Id
    private String id;

    @NotEmpty
    @NotNull
    @TextIndexed(weight = Number.FOUR)
    @Size(min = Number.TEN, max = Number.NINETY)
    private String title;

    private List<String> tags = new ArrayList<>();

    @NotEmpty
    @NotNull
    private String content;

    private Date dataModified;

    private Date dateCreated = new Date();

    private List<DocumentInfo> documents = new ArrayList<>();

    private boolean verified = false;

    @ValidEnum(enumClass = ContentType.class)
    private String contentType;

    private int likeCount = 1;

    private List<Approval> approvals = new ArrayList<>();

    @Valid
    private Author author;
}
