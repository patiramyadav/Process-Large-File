package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miyoz.qcollect.api.models.Model;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * Created by sabin on 12/9/2017.
 */
@Data
public class Email extends Model<String> {
    @JsonIgnore
    private String id;
    private String from;
    private String to;
    private String subject;
    private List<Object> attachments;
    private Map<String, Object> model;
    private String token;
}
