package com.miyoz.qcollect.api.validators.fileValidator;

import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class FileValidator {
    private Pattern pattern;
    private Matcher matcher;

    private static final String DOCUMENT_PATTERN = "([^\\s]+(\\.(?i)(JPG|PNG|PDF|JPEG))$)";

    public FileValidator() {
        pattern = Pattern.compile(DOCUMENT_PATTERN);
    }

    public boolean validate(final String docType) {
        matcher = pattern.matcher(docType.replaceAll("\\s+", "").toUpperCase());
        return matcher.matches();

    }
}
