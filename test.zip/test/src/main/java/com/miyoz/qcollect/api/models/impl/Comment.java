package com.miyoz.qcollect.api.models.impl;

import com.miyoz.qcollect.api.utils.Number;
import lombok.*;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;

/**
 * Created by Yogen on 11/22/2017.
 */
@Getter
@Setter
@ToString
@Document(collection = "comment")
public class Comment {
    @Id
    private String id;

    @NotEmpty
    @NotNull
    private String questionId;

    private String commenterName;
    private Date dateCreated;

    @NotEmpty
    @NotNull
    @Size(min = Number.TEN, max = Number.HUNDRED_EIGHTY)
    private String content;
}
