package com.miyoz.qcollect.api.models.impl;

import com.miyoz.qcollect.api.models.Model;
import com.miyoz.qcollect.api.models.types.GenderType;
import com.miyoz.qcollect.api.validators.enumValidator.ValidEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@ToString
@Document(collection = "profile")
public class Profile extends Model<String> {

    @Id
    private String id;

    private Date dob;

    @NotEmpty
    @NotNull
    @ValidEnum(enumClass = GenderType.class)
    private String gender;

    @NotEmpty
    @NotNull
    private String phoneNumber;

    private Date dataModified;

    private Date dateCreated;

    private List<SocialLink> socialMediaLinks;

    @NotEmpty
    @NotNull
    private String userId;

    private List<DocumentInfo> documents;

    private boolean active;
}
