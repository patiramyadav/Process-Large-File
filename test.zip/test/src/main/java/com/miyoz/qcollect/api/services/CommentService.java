package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.Comment;

import java.util.List;

public interface CommentService extends CommonService<String, Comment> {
    List<Comment> findByQuestionId(String questionId);
}
