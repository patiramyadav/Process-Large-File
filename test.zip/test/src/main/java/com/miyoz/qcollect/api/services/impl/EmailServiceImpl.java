package com.miyoz.qcollect.api.services.impl;

import com.miyoz.qcollect.api.models.impl.Email;
import com.miyoz.qcollect.api.services.EmailService;
import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import javax.mail.internet.MimeMessage;
import java.nio.charset.StandardCharsets;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class EmailServiceImpl implements EmailService {
    private final JavaMailSender mailSender;

    private final Configuration freemarkerConfig;

    @Async
    @Override
    public void sendEmail(SimpleMailMessage email) {
        try {
            this.mailSender.send(email);
        } catch (MailException ex) {
            log.debug("Sending email failed to {}", email.getTo());
        }
    }

    @Async
    @Override
    public void sendEmail(Email email, boolean withVerificationCode) throws Exception {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message,
                    MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
                    StandardCharsets.UTF_8.name());

            helper.addAttachment("logo.png", new ClassPathResource("images/logo.png"));
            freemarkerConfig.setClassForTemplateLoading(this.getClass(), "/template/");

            Template t;

            if (withVerificationCode) {
                t = freemarkerConfig.getTemplate("email-with-code-template.ftl");
            } else {
                t = freemarkerConfig.getTemplate("email-template.ftl");
            }

            String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, email.getModel());
            helper.setTo(email.getTo());
            helper.setText(html, true);
            helper.setSubject(email.getSubject());
            helper.setFrom(email.getFrom());
            mailSender.send(message);
        } catch (MailException ex) {
            log.error(ex.toString());
            log.debug("Sending email failed to {}", email.getTo());
        }
    }

}
