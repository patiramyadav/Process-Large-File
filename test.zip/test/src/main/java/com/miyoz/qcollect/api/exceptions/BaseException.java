package com.miyoz.qcollect.api.exceptions;

public class BaseException extends RuntimeException {
    public BaseException(String message) {
        super(message);
    }
}
