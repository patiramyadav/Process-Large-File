package com.miyoz.qcollect.api.exceptions;

import lombok.Getter;
import org.springframework.validation.Errors;

@Getter
public class DataException extends BaseException {
    /**
     * Serial UUID
     */
    private static final long serialVersionUID = 2502363624937013988L;

    private final Errors errors;

    public DataException(String message, Errors errors) {
        super(message);
        this.errors = errors;
    }

}
