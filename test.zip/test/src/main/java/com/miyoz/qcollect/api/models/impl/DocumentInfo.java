package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miyoz.qcollect.api.models.Model;
import lombok.*;
import org.springframework.data.annotation.Transient;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DocumentInfo extends Model<String> {
    @Transient
    @JsonIgnore
    private String id;

    private String docName;

    private String s3key;

    private String url;
}
