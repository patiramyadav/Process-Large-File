package com.miyoz.qcollect.api.repositories;

import com.miyoz.qcollect.api.models.impl.Question;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface QuestionRepository extends MongoRepository<Question, String> {
    List<Question> findByIdIn(List<String> ids);

    Page<Question> findByIdIn(Pageable pageable, List<String> ids);

    @Query("{ contributor._id : ?0}")
    Page<Question> findByContributorId(Pageable pageable, String contributorId);

    @Query("{$and : [{level:?0}, {verified: true}]}")
    Page<Question> findForLevel(Pageable pageable, String level);

    @Query("{ $text: { $search: ?0, $caseSensitive: false}}")
    Page<Question> searchQuestions(Pageable pageable, String keyword);

    @Query("{ $and: [{ $text: { $search: ?0, $caseSensitive: false}}, { contributor._id : ?1}]}")
    Page<Question> searchQuestions(Pageable pageable, String keyword, String userId);

    @Query("{$and : [{subject:?0}, {year: ?1}, {semester:?2}, {university: ?3}, {program: ?4}]}")
    Question findQuestion(String subject, int year, String semester, String university, String program);

    @Query("{$and : [{subject:?0}, {year: ?1}, {semester:?2}, {university: ?3}, {program: ?4}, {contentType: ?5}]}")
    Question findQuestion(String subject, int year, String semester, String university, String program, String contentType);

    @Query("{ subject: {'$regex':?0, '$options':'i'}}")
    Page<Question> findByCourseName(Pageable pageable, String course);

    //level (SSE)--> sub  -->year
    @Query("{$and : [{level:?0}, {verified: true}]}")
    Page<Question> findForSchool(Pageable pageable, String level);

    @Query("{$and : [{level:?0}, {year: ?1}, {verified: true}]}")
    Page<Question> findForSchool(Pageable pageable, String level, int year);

    @Query("{$and : [{level:?0}, {year: ?1}, {subject: {'$regex':?2, '$options':'i'}}, {verified: true}]}")
    Page<Question> findForSchool(Pageable pageable, String level, int year, String subject);


    //level (10+1 and 10+2)--> sub  --> year
    @Query("{$and : [{level:?0}, {faculty: ?1}, {year: ?2}, {subject: {'$regex':?3, '$options':'i'}}, {verified: true}]}")
    Page<Question> findForInter(Pageable pageable, String level, String faculty, Integer year, String subject);

    @Query("{$and : [{level:?0}, {faculty: ?1}, {year: ?2}, {verified: true}]}")
    Page<Question> findForInter(Pageable pageable, String level, String faculty, Integer year);

    @Query("{$and : [{level:?0}, {faculty: ?1}, {verified: true}]}")
    Page<Question> findForInter(Pageable pageable, String level, String faculty);

    //level (bachelors) --> university --> program --> sem --> year --> sub
    //level (masters) --> uni --> program --> sem --> year --> sub
    @Query("{$and : [{level:?0}, {university: ?1}, {program: {'$regex':?2, '$options':'i'}}, {semester: ?3}, {verified: true}]}")
    Page<Question> findForCollege(Pageable pageable, String level, String university, String program, String semester);

    @Query("{$and : [{level:?0}, {university: ?1}, {program: {'$regex':?2, '$options':'i'}}, {semester: ?3}, {subject: {'$regex':?4, '$options':'i'}}, {verified: true}]}")
    Page<Question> findForCollegeByCourse(Pageable pageable, String level, String university, String program, String semester, String course);

    @Query("{$and : [{level:?0}, {university: ?1}, {program: {'$regex':?2, '$options':'i'}}, {semester: ?3}, {year: ?4}, {verified: true}]}")
    Page<Question> findForCollege(Pageable pageable, String level, String university, String program, String semester, int year);

    @Query("{$and : [{level:?0}, {university: ?1}, {program: {'$regex':?2, '$options':'i'}}, {semester: ?3}, {year: ?4}, {subject: {'$regex':?5, '$options':'i'}}, {verified: true}]}")
    Page<Question> findForCollege(Pageable pageable, String level, String university, String program, String semester, int year, String subject);
}
