package com.miyoz.qcollect.api.data.mock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.repositories.ProfileRepository;
import com.miyoz.qcollect.api.repositories.QuestionRepository;
import com.miyoz.qcollect.api.repositories.UserRepository;
import com.miyoz.qcollect.api.utils.QCollectProfiles;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.io.File;
import java.util.Date;
import java.util.List;

@Slf4j
@Configuration
@Profile({"!" + QCollectProfiles.PROD})
public class MockDataLoader implements CommandLineRunner {
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProfileRepository profileRepository;

    @Autowired
    private QuestionRepository questionRepository;

    @Override
    public void run(String... arg0) throws Exception {

        String userURL = "/data/users.json";
        String profileURL = "/data/profiles.json";
        String questionURL = "/data/questions.json";

        //setup user data
        if ((this.userRepository.findAll()).isEmpty()) {
            setUpData(userURL, "User");
        }
        //setup profile data
        if ((this.profileRepository.findAll()).isEmpty()) {
            setUpData(profileURL, "Profile");
        }

        //setup question data
        if ((this.questionRepository.findAll()).isEmpty()) {
            setUpData(questionURL, "Question");
        }
    }

    public void setUpData(String url, String className) throws Exception {
        Resource rsrc = new ClassPathResource(url);
        String path = rsrc.getFile().getAbsolutePath();
        ObjectMapper mapper = new ObjectMapper();
        switch (className) {
            case "User":
                List<User> users = mapper.readValue(new File(path), mapper.getTypeFactory().constructCollectionType(List.class, User.class));
                users.forEach(user -> {
                    user.setPassword(this.passwordEncoder.encode(user.getPassword()));
                    user.setDateCreated(new Date());
                });
                this.userRepository.save(users);
                log.debug("{} Users saved.", users.size());
                break;
            case "Profile":
                List<com.miyoz.qcollect.api.models.impl.Profile> profiles = mapper.readValue(new File(path), mapper.getTypeFactory().constructCollectionType(List.class, com.miyoz.qcollect.api.models.impl.Profile.class));
                this.profileRepository.save(profiles);
                log.debug("{} Profiles saved.", profiles.size());
                break;

            case "Question":
                List<Question> questions = mapper.readValue(new File(path), mapper.getTypeFactory().constructCollectionType(List.class, Question.class));
                this.questionRepository.save(questions);
                log.debug("{} Questions saved.", questions.size());
                break;

            default:
                log.debug("No json data found");
        }
    }
}

