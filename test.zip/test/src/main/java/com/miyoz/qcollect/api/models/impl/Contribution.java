package com.miyoz.qcollect.api.models.impl;

import com.miyoz.qcollect.api.models.Model;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
@ToString
@Document(collection = "contribution")
public class Contribution extends Model<String> {

    @Id
    private String id;

    @NotEmpty
    @NotNull
    private String userId;

    private List<String> questionIds;
}
