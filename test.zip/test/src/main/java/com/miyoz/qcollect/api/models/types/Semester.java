package com.miyoz.qcollect.api.models.types;

public enum Semester {
    I,
    II,
    III,
    IV,
    V,
    VI,
    VII,
    VIII
}
