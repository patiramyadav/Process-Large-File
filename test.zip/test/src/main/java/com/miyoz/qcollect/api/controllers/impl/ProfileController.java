package com.miyoz.qcollect.api.controllers.impl;

import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Profile;
import com.miyoz.qcollect.api.models.interfaces.impl.ProfileResponse;
import com.miyoz.qcollect.api.services.ProfileService;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Optional;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
@RestController
public class ProfileController implements BaseController<Profile> {
    private final ProfileService profileService;

    @GetMapping(value = "/users/{userId}/profile")
    public ResponseEntity<ProfileResponse> getProfile(
            @ApiParam(value = "User Id as path variable", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
            @RequestHeader("Authorization") final String authorization) {
        Optional<Profile> profileOptional = profileService.findByUserId(userId);
        return profileOptional.map(profile -> {
            final ProfileResponse profileResponse = new ProfileResponse(profile);
            profileResponse.setProfile(profile);
            profileResponse.add(linkTo(methodOn(ProfileController.class).getProfile(userId, authorization)).withSelfRel());
            return new ResponseEntity<>(profileResponse, HttpStatus.OK);
        }).orElseThrow(() -> new NotFoundException(ErrorCodes.EXC404.toString(), null));
    }

    @PostMapping(value = "/users/{userId}/profile", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<ProfileResponse> createProfile(
            @ApiParam(value = "Request Body for Profile", required = true) @Valid @RequestBody Profile profile,
            BindingResult bindingResult,
            @ApiParam(value = "User Id as path variable", required = true) @PathVariable("userId") String userId,
            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
            @RequestHeader("Authorization") final String authorization) {
        if (bindingResult.hasErrors()) {
            throw new DataException(ErrorCodes.EXC400.toString(), bindingResult);
        }
        Profile createdProfile = this.profileService.create(profile);
        log.info("Profile with profileId: {} is created.", createdProfile.getId());
        final ProfileResponse profileResponse = new ProfileResponse(createdProfile);
        profileResponse.add(linkTo(methodOn(ProfileController.class).createProfile(profile, bindingResult, userId, authorization)).withSelfRel());
        return new ResponseEntity<>(profileResponse, HttpStatus.CREATED);
    }

    @PutMapping(value = "/users/{userId}/profile", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<ProfileResponse> updateProfile(@ApiParam(value = "Request Body for Profile", required = true) @Valid @RequestBody Profile profile,
                                                         BindingResult bindingResult,
                                                         @ApiParam(value = "User Id as path variable", required = true) @PathVariable("userId") String userId,
                                                         @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                         @RequestHeader("Authorization") final String authorization) {
        if (bindingResult.hasErrors()) {
            throw new DataException(ErrorCodes.EXC400.toString(), bindingResult);
        }
        final Profile profileUpdated = this.profileService.update(profile);
        final ProfileResponse profileResponse = new ProfileResponse(profileUpdated);
        profileResponse.add(linkTo(methodOn(ProfileController.class).updateProfile(profile, bindingResult, userId, authorization)).withSelfRel());
        return new ResponseEntity<>(profileResponse, HttpStatus.OK);
    }

    @DeleteMapping(value = "/users/{userId}/profile", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> deleteProfile(@ApiParam(value = "User Id as path variable", required = true) @PathVariable("userId") String userId,
                                           @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                           @RequestHeader("Authorization") final String authorization) {
        this.profileService.delete(userId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
