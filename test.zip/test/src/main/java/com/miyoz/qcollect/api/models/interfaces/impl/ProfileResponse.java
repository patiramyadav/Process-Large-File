package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.impl.Profile;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.hateoas.ResourceSupport;

@Getter
@Setter
@AllArgsConstructor
public class ProfileResponse extends ResourceSupport {
    private Profile profile;
}
