package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miyoz.qcollect.api.models.Model;
import lombok.*;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Transient;

import javax.validation.constraints.NotNull;

@Getter
@Setter
@ToString
public class SocialLink extends Model<String> {
    @JsonIgnore
    @Transient
    private String id;

    @NotEmpty
    @NotNull
    private String site;

    @NotEmpty
    @NotNull
    private String link;
}
