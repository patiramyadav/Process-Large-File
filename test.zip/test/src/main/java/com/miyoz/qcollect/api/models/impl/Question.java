package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.miyoz.qcollect.api.models.Model;
import com.miyoz.qcollect.api.models.types.*;
import com.miyoz.qcollect.api.utils.Number;
import com.miyoz.qcollect.api.validators.enumValidator.ValidEnum;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.TextIndexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "question")
public class Question extends Model<String> {

    @Id
    private String id;

    @NotEmpty
    @NotNull
    @ValidEnum(enumClass = LevelType.class)
    @TextIndexed(weight = Number.FOUR)
    private String level;

    @NotEmpty
    @NotNull
    @TextIndexed(weight = Number.SEVEN)
    private String subject;

    @NotEmpty
    @NotNull
    @TextIndexed(weight = Number.SIX)
    private String faculty;

    @NotEmpty
    @NotNull
    private String content;

    @NotNull
    @Min(Number.TWO_THOUSAND)
    @Max(Number.TWENTY_ONE_HUNDRED)
    @TextIndexed(weight = Number.FOUR)
    private int year;

    @NotNull
    @NotEmpty
    @ValidEnum(enumClass = Semester.class)
    @TextIndexed(weight = Number.FOUR)
    private String semester;

    @NotNull
    @NotEmpty
    @ValidEnum(enumClass = UniversityType.class)
    @TextIndexed(weight = Number.FOUR)
    private String university;

    @ValidEnum(enumClass = ProgramType.class)
    private String program;

    private Date dataModified;

    private Date dateCreated;

    private List<DocumentInfo> documents = new ArrayList<>();

    private boolean verified;

    @ValidEnum(enumClass = ContentType.class)
    private String contentType;

    private int likeCount = 1;

    private List<Approval> approvals = new ArrayList<>();

    @Valid
    private Author contributor;
}
