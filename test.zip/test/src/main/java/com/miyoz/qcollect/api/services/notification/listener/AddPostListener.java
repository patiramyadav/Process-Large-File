package com.miyoz.qcollect.api.services.notification.listener;

import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.services.NotificationService;
import com.miyoz.qcollect.api.services.notification.OnAddSyllabusEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;


@Component
public class AddPostListener implements ApplicationListener<OnAddSyllabusEvent> {

    @Autowired
    private NotificationService notificationService;

    @Override
    public void onApplicationEvent(OnAddSyllabusEvent onAddSyllabusEvent) {
        this.sendPushNotification(onAddSyllabusEvent);
    }

    private void sendPushNotification(OnAddSyllabusEvent onAddSyllabusEvent) {
        Question addedQuestion = onAddSyllabusEvent.getSyllabus();
        Question question = new Question();
        question.setId(addedQuestion.getId());
        this.notificationService.sendPushNotification(question);
    }
}
