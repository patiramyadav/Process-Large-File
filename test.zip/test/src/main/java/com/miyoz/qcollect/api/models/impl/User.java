package com.miyoz.qcollect.api.models.impl;

import com.miyoz.qcollect.api.models.Model;
import com.miyoz.qcollect.api.models.types.RoleType;
import com.miyoz.qcollect.api.validators.enumValidator.ValidEnum;
import lombok.*;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexType;
import org.springframework.data.mongodb.core.index.GeoSpatialIndexed;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "user")
public class User extends Model<String> {
    @Id
    private String id;

    @NotEmpty
    @NotNull
    private String firstName;

    @NotEmpty
    @NotNull
    private String lastName;

    @Email
    @NotEmpty
    @Indexed(unique = true)
    private String email;

    private String password;

    private Date dateCreated;

    private boolean active;

    private boolean emailVerified;

    @NotNull
    @ValidEnum(enumClass = RoleType.class)
    private String role;

    private Address address;

    @GeoSpatialIndexed(type = GeoSpatialIndexType.GEO_2DSPHERE)
    private Coordinate eqvtCoordinate;

    private List<String> expertise;

    private String photoUrl;
}
