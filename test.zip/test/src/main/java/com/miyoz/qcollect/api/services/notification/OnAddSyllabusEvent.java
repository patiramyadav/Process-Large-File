package com.miyoz.qcollect.api.services.notification;

import com.miyoz.qcollect.api.models.impl.Question;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class OnAddSyllabusEvent extends ApplicationEvent {
    private Question syllabus;

    public OnAddSyllabusEvent(Question source) {
        super(source);
        this.syllabus = source;
    }
}
