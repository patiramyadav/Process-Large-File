package com.miyoz.qcollect.api.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Number {
    public static final int FOUR = 4;
    public static final int SIX = 6;
    public static final int SEVEN = 7;
    public static final int TEN = 10;
    public static final int NINETY = 90;
    public static final int HUNDRED = 100;
    public static final int HUNDRED_EIGHTY = 180;
    public static final int FIVE_HUNDRED = 500;
    public static final long ONE_DAY = 24 * 60 * 60 * 1000;
    public static final long TWO_DAY = 2 * 24 * 60 * 60 * 1000;
    public static final long HALF_MONTH = 15 * 24 * 60 * 60 * 1000;
    public static final double METER_PER_MILE = 1609.34;
    public static final int TWO_THOUSAND = 2000;
    public static final int TWENTY_ONE_HUNDRED = 2100;
    public static final int THIRTY_SECOND = 30 * 1000;
}
