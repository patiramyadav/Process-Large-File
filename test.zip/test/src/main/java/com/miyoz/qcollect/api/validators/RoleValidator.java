package com.miyoz.qcollect.api.validators;

import com.miyoz.qcollect.api.security.models.AuthenticatedUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Collection;

import static com.miyoz.qcollect.api.models.types.RoleType.ROLE_ADMIN;
import static com.miyoz.qcollect.api.models.types.RoleType.ROLE_SUPER_ADMIN;

/**
 * Created by Yogen on 11/24/2017.
 */
@Slf4j
@Component
public class RoleValidator {
    public void validateRole(String role) {
        //check if role is ok
        SecurityContext context = SecurityContextHolder.getContext();
        Authentication auth = context.getAuthentication();
        Collection<? extends GrantedAuthority> loggedInUserRole = (((AuthenticatedUser) auth.getPrincipal()).getAuthorities());
        for (GrantedAuthority ga : loggedInUserRole) {
            if (ROLE_SUPER_ADMIN.toString().equals(ga.getAuthority())) {
                return;
            }

            if (ROLE_ADMIN.toString().equals(ga.getAuthority()) && !ROLE_SUPER_ADMIN.toString().equals(role)) {
                return;
            }

            if (!ga.getAuthority().equals(role)) {
                throw new AuthenticationServiceException("Unauthorized");
            }
        }
    }
}
