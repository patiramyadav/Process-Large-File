package com.miyoz.qcollect.api.config;

import de.bytefish.fcmjava.http.options.IFcmClientSettings;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "fcm")
@Component
@Setter
public class FcmPropertiesConfig implements IFcmClientSettings {
    private String apiKey;
    private String url;

    @Override
    public String getFcmUrl() {
        return this.url;
    }

    @Override
    public String getApiKey() {
        return this.apiKey;
    }
}
