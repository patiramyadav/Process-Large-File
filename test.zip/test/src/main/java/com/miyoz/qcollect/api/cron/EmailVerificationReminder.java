package com.miyoz.qcollect.api.cron;

import com.miyoz.qcollect.api.models.impl.Email;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.impl.UserToken;
import com.miyoz.qcollect.api.models.types.RoleType;
import com.miyoz.qcollect.api.repositories.UserRepository;
import com.miyoz.qcollect.api.repositories.UserTokenRepository;
import com.miyoz.qcollect.api.services.EmailService;
import com.miyoz.qcollect.api.utils.EmailConstructor;
import com.miyoz.qcollect.api.utils.Number;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class EmailVerificationReminder {
    @Value("${url.verify.email}")
    private String url;

    @Value("${email.body.remainderEmailVerify}")
    private String emailBody;

    @Value("${email.body.remainderEmailVerifyWithCode}")
    private String emailBodyWithCode;

    @Value("${email.subject.emailVerify}")
    private String emailSubject;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserTokenRepository userTokenRepository;

    @Autowired
    private EmailService emailService;

    @Scheduled(cron = "* * 8 * * SAT")
    public void findEmailNotVerifiedUsers() {
        Date dateBefore = new Date(DateTime.now().minusDays(Number.FOUR).getMillis());
        List<User> emailNotVerifiedUsers = this.userRepository.findByVerificationStatus(dateBefore, false);

        List<String> userIds = emailNotVerifiedUsers.stream().map(User::getId).collect(Collectors.toList());

        List<UserToken> expiredTokens = this.userTokenRepository.findByUserIdIn(userIds);

        this.userTokenRepository.delete(expiredTokens);

        emailNotVerifiedUsers.forEach(this::sendRemainderEmail);
    }

    private void sendRemainderEmail(User user) {

        UserToken savedUserToken = this.userTokenRepository.save(EmailConstructor.createUserToken(user));

        try {
            Email email;
            if (RoleType.ROLE_VIEWER.toString().equals(user.getRole())) {
                email = EmailConstructor.setMobileMailBody(savedUserToken.getVerificationCode(), user, emailBodyWithCode, emailSubject);
            } else {
                email = EmailConstructor.setMailBody(url, savedUserToken.getToken(), user, emailBody, emailSubject);
            }
            this.emailService.sendEmail(email, RoleType.ROLE_VIEWER.toString().equals(user.getRole()));
        } catch (Exception ex) {
            log.error("Sending email failed to {}", user.getEmail());
        }

    }
}