package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.interfaces.BaseResponse;
import org.springframework.hateoas.ResourceSupport;

public class GenericResponse  extends ResourceSupport implements BaseResponse {
}
