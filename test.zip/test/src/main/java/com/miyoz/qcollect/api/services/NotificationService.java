package com.miyoz.qcollect.api.services;

public interface NotificationService {
    void sendPushNotification(Object message);
}
