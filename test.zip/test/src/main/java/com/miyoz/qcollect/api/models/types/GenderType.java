package com.miyoz.qcollect.api.models.types;

public enum GenderType {
    MALE,
    FEMALE
}
