package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.Email;
import org.springframework.mail.SimpleMailMessage;

public interface EmailService {
    void sendEmail(SimpleMailMessage email);

    void sendEmail(Email email, boolean withVerificationCode) throws Exception;
}
