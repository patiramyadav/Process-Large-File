package com.miyoz.qcollect.api.services.registration.listener;

import com.miyoz.qcollect.api.models.impl.Email;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.impl.UserToken;
import com.miyoz.qcollect.api.models.types.RoleType;
import com.miyoz.qcollect.api.services.EmailService;
import com.miyoz.qcollect.api.services.UserTokenService;
import com.miyoz.qcollect.api.services.registration.OnRegistrationCompleteEvent;
import com.miyoz.qcollect.api.utils.EmailConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class RegistrationListener implements ApplicationListener<OnRegistrationCompleteEvent> {

    @Value("${url.verify.email}")
    private String url;

    @Value("${email.body.emailVerify}")
    private String emailBody;

    @Value("${email.body.emailVerifyWithCode}")
    private String emailBodyWithCode;

    @Value("${email.body.accountCreated}")
    private String accountCreated;

    @Value("${email.subject.accountCreated}")
    private String accountCreatedSubject;

    @Value("${email.subject.emailVerify}")
    private String emailSubject;

    @Value("${url.reset.password}")
    private String passwordResetUrl;

    @Autowired
    private UserTokenService userTokenService;

    @Autowired
    private EmailService emailService;

    @Override
    public void onApplicationEvent(final OnRegistrationCompleteEvent event) {
        this.confirmRegistration(event);
    }

    private void confirmRegistration(final OnRegistrationCompleteEvent event) {
        final User user = event.getUser();

        UserToken savedUserToken = this.userTokenService.createVerificationTokenForUser(EmailConstructor.createUserToken(user));

        try {
            Email email;
            if (user.isEmailVerified()) {
                String sb = accountCreated +
                        "<br/>" +
                        "Username: " + user.getEmail() + "<br/>" +
                        "Password: " + user.getPassword() + "<br/><br/>" +
                        "If you want to reset password, go to settings and change password or click the url below <br/>";
                email = EmailConstructor.setVerifiedMailBody(passwordResetUrl, user, sb, accountCreatedSubject);
            } else if (RoleType.ROLE_VIEWER.toString().equals(user.getRole())) {
                email = EmailConstructor.setMobileMailBody(savedUserToken.getVerificationCode(), user, emailBodyWithCode, emailSubject);
            } else {
                email = EmailConstructor.setMailBody(url, savedUserToken.getToken(), user, emailBody, emailSubject);
            }
            this.emailService.sendEmail(email, RoleType.ROLE_VIEWER.toString().equals(user.getRole()));
        } catch (Exception ex) {
            log.error("Sending email failed to {}", user.getEmail());
        }

    }
}
