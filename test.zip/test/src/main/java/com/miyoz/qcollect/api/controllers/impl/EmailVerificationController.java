package com.miyoz.qcollect.api.controllers.impl;

import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.impl.UserToken;
import com.miyoz.qcollect.api.models.interfaces.impl.GenericResponse;
import com.miyoz.qcollect.api.services.UserService;
import com.miyoz.qcollect.api.services.UserTokenService;
import com.miyoz.qcollect.api.services.registration.OnRegistrationCompleteEvent;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

@Controller
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class EmailVerificationController implements BaseController<String> {

    private final UserTokenService userTokenService;
    private final UserService userService;
    private final ApplicationEventPublisher eventPublisher;

    @GetMapping(value = "/user/verify-email")
    public ResponseEntity<GenericResponse> verifyAccountToken(@ApiParam(value = "User ID", required = true) @RequestParam(value = "userId") String userId,
                                                              @ApiParam(value = "Token", required = true) @RequestParam(value = "token") String token) {
        UserToken userToken = this.userTokenService.findByUserIdAndToken(userId, token);
        return this.userService.findOne(userToken.getUserId()).map(user -> {
            user.setActive(true);
            user.setEmailVerified(true);
            this.userService.update(user);
            this.userTokenService.deleteToken(userToken);
            GenericResponse response = new GenericResponse();
            response.add(linkTo(methodOn(EmailVerificationController.class).verifyAccountToken(userId, token)).withSelfRel());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }).orElseThrow(() -> new NotFoundException(ErrorCodes.EXC404.toString(), null));
    }

    @GetMapping(value = "/user/verify-email-pin")
    public ResponseEntity<GenericResponse> verifyAccountPin(@ApiParam(value = "PIN", required = true) @RequestHeader(value = "pin") String pin) {
        UserToken userToken = this.userTokenService.findByPin(pin);
        return this.userService.findOne(userToken.getUserId()).map(user -> {
            user.setActive(true);
            user.setEmailVerified(true);
            this.userService.update(user);
            this.userTokenService.deleteToken(userToken);
            GenericResponse response = new GenericResponse();
            response.add(linkTo(methodOn(EmailVerificationController.class).verifyAccountPin(pin)).withSelfRel());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }).orElseThrow(() -> new NotFoundException(ErrorCodes.EXC404.toString(), null));
    }

    @GetMapping(value = "/user/re-send-email")
    public ResponseEntity<?> reSendEmailVerification(@ApiParam(value = "User ID", required = true) @RequestParam(value = "userId") String userId) {
        UserToken userToken = userTokenService.findByUserId(userId);
        return this.userService.findOne(userToken.getUserId()).map(user -> {
            this.userTokenService.deleteToken(userToken);
            eventPublisher.publishEvent(new OnRegistrationCompleteEvent(user));
            return new ResponseEntity<>(HttpStatus.CREATED);
        }).orElseThrow(() -> new NotFoundException(ErrorCodes.EXC404.toString(), null));
    }

    @GetMapping(value = "/user/re-send-code")
    public ResponseEntity<?> reSendEmailVerificationCode(@ApiParam(value = "User Email", required = true) @RequestHeader("email") String email) {
        User user = this.userService.findUserByEmail(email);

        UserToken userToken = userTokenService.findByUserId(user.getId());

        this.userTokenService.deleteToken(userToken);
        eventPublisher.publishEvent(new OnRegistrationCompleteEvent(user));
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}
