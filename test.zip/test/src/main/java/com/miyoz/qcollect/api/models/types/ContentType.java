package com.miyoz.qcollect.api.models.types;

public enum ContentType {
    QUESTION,
    SYLLABUS,
    ARTICLE,
    ROUTINE,
    RESULT,
    OTHER
}
