package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.dtos.UserDto;
import com.miyoz.qcollect.api.models.impl.Contribution;
import com.miyoz.qcollect.api.models.impl.Profile;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class FullProfileResponse extends ResourceSupport {
    private UserDto user;
    private Profile profile;
    private List<Contribution> interests;
}
