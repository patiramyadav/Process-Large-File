package com.miyoz.qcollect.api.services.impl;

import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.UserToken;
import com.miyoz.qcollect.api.repositories.UserTokenRepository;
import com.miyoz.qcollect.api.services.UserTokenService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;


@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class UserTokenServiceImpl implements UserTokenService {

    private final UserTokenRepository userTokenRepository;

    private static final String USER_TOKEN_NOT_FOUND = "User token not found.";

    @Override
    public UserToken createVerificationTokenForUser(UserToken userToken) {
        return this.userTokenRepository.save(userToken);
    }

    @Override
    public UserToken findByUserIdAndToken(String userId, String token) {
        final UserToken userToken = this.userTokenRepository.findByUserIdAndToken(userId, token);

        if (userToken == null) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "token", USER_TOKEN_NOT_FOUND);
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        } else if (userToken.getExpiryDate().before(new Date())) {
            Error error = new Error(ErrorCodes.EXC400.toString(), "token", "Token Expired.");
            deleteToken(userToken);
            throw new NotFoundException(ErrorCodes.EXC400.toString(), error);
        }
        return userToken;
    }

    @Override
    public UserToken findByPin(String pin) {
        final UserToken userToken = this.userTokenRepository.findByVerificationCode(pin);
        if (userToken == null) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "token", USER_TOKEN_NOT_FOUND);
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        } else if (userToken.getExpiryDate().before(new Date())) {
            Error error = new Error(ErrorCodes.EXC400.toString(), "token", "Token Expired.");
            deleteToken(userToken);
            throw new NotFoundException(ErrorCodes.EXC400.toString(), error);
        }
        return userToken;
    }

    @Override
    public UserToken findByUserId(String userId) {
        UserToken userToken = userTokenRepository.findByUserId(userId);
        if (null == userToken) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "token", USER_TOKEN_NOT_FOUND);
            throw new NotFoundException(ErrorCodes.EXC400.toString(), error);
        }
        return userToken;
    }

    @Override
    public void deleteToken(UserToken userToken) {
        this.userTokenRepository.delete(userToken);
    }
}
