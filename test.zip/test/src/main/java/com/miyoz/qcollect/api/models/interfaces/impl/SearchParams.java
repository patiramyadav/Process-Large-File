package com.miyoz.qcollect.api.models.interfaces.impl;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
public class SearchParams {
    private String university;

    private String faculty;

    private String subject;

    private String level;

    private Integer year;

    private String semester;

    private String keyword;

    private String program;

    private String contentType;
}
