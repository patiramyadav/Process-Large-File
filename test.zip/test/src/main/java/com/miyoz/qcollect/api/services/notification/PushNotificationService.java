package com.miyoz.qcollect.api.services.notification;

import com.miyoz.qcollect.api.services.NotificationService;
import de.bytefish.fcmjava.http.client.IFcmClient;
import de.bytefish.fcmjava.model.enums.ErrorCodeEnum;
import de.bytefish.fcmjava.model.options.FcmMessageOptions;
import de.bytefish.fcmjava.model.topics.Topic;
import de.bytefish.fcmjava.requests.notification.NotificationPayload;
import de.bytefish.fcmjava.requests.topic.TopicUnicastMessage;
import de.bytefish.fcmjava.responses.TopicMessageResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class PushNotificationService implements NotificationService {
    public static final String TOPIC_NAME = "QCollectNotification";
    private final IFcmClient fcmClient;

    /*@Scheduled(fixedDelay = Number.THIRTY_SECOND)
    public void sendChuckQuotes() {
        String message = "Test notification!!";
        sendPushNotification(message);
    }
*/
    @Override
    public void sendPushNotification(Object messageText) {
        FcmMessageOptions options = FcmMessageOptions.builder()
                .setTimeToLive(Duration.ofMinutes(2)).build();

        NotificationPayload payload = NotificationPayload.builder()
                .setBody("New Content has been added.").setTitle("Q-Collect Update")
                .setTag("qcollect").build();

        Map<String, Object> data = new HashMap<>();
        data.put("id", "1");
        data.put("text", messageText);

        // Send a message
        log.info("Sending notification...");

        Topic topic = new Topic(TOPIC_NAME);
        TopicUnicastMessage message = new TopicUnicastMessage(options, topic, data, payload);

        TopicMessageResponse response = this.fcmClient.send(message);
        ErrorCodeEnum errorCode = response.getErrorCode();
        if (errorCode != null) {
            log.debug("Topic message sending failed: {}", errorCode);
        }
    }
}
