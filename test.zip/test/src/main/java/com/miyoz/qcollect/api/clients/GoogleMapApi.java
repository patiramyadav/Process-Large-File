package com.miyoz.qcollect.api.clients;

import com.google.maps.model.LatLng;

/**
 * @author Yogen
 */
public interface GoogleMapApi {
    LatLng getLatLng(String address);

    String getFormattedAddress(double lat, double lng);
}
