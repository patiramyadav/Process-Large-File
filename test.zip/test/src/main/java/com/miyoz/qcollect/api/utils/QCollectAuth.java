package com.miyoz.qcollect.api.utils;

import com.miyoz.qcollect.api.models.types.RoleType;
import com.miyoz.qcollect.api.security.models.AuthenticatedUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collection;

/**
 * @author Yogen
 */
public class QCollectAuth {

    public static boolean isRoleContributor() {
        //check if role is ok
        Collection<? extends GrantedAuthority> loggedInUserRole = getCurrentUser().getAuthorities();
        return loggedInUserRole.stream().anyMatch(role -> RoleType.ROLE_CONTRIBUTOR.toString().equals(role.getAuthority()));
    }

    public static boolean isRoleViewer() {
        //check if role is ok
        Collection<? extends GrantedAuthority> loggedInUserRole = getCurrentUser().getAuthorities();
        return loggedInUserRole.stream().anyMatch(role -> RoleType.ROLE_VIEWER.toString().equals(role.getAuthority()));
    }

    public static boolean isRoleAdmin() {
        //check if role is ok
        Collection<? extends GrantedAuthority> loggedInUserRole = getCurrentUser().getAuthorities();
        return loggedInUserRole.stream().anyMatch(role -> RoleType.ROLE_ADMIN.toString().equals(role.getAuthority()));
    }

    public static AuthenticatedUser getCurrentUser() {
        //check if role is ok
        SecurityContext context = SecurityContextHolder.getContext();
        Authentication auth = context.getAuthentication();
        return (AuthenticatedUser) auth.getPrincipal();
    }
}
