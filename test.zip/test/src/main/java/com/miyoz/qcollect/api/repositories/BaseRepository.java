/**
 *
 */
package com.miyoz.qcollect.api.repositories;

/**
 * @author Yogen
 */
public interface BaseRepository {

}
