package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.Document;
import com.miyoz.qcollect.api.models.impl.DocumentInfo;

public interface FileArchiveService {
    DocumentInfo saveFilesToS3(Document document);

    void deleteFilesFromS3(String s3key);
}
