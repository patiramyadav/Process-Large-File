package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.impl.Question;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class QuestionResponse extends ResourceSupport {
    private List<Question> questions;
}
