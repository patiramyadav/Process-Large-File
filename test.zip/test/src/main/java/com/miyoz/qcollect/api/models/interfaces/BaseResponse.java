package com.miyoz.qcollect.api.models.interfaces;

public interface BaseResponse {
    //intentionally left blank
}
