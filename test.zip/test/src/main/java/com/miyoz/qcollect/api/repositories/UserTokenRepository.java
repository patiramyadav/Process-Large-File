package com.miyoz.qcollect.api.repositories;

import com.miyoz.qcollect.api.models.impl.UserToken;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface UserTokenRepository extends MongoRepository<UserToken, String> {

    UserToken findByUserIdAndToken(String userId, String token);

    UserToken findByVerificationCode(String pin);

    UserToken findByUserId(String userId);

    List<UserToken> findByUserIdIn(List<String> userIds);
}
