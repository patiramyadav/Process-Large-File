package com.miyoz.qcollect.api.controllers.impl;

import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.services.MigrationService;
import com.miyoz.qcollect.api.services.QuestionService;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class MigrationController implements BaseController<Question> {

    private final QuestionService questionService;

    private final MigrationService migrationService;

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN')")
    @GetMapping(value = "/questions/migration-update-author")
    public ResponseEntity<?> migrateQuestionAuthor(
            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
            @RequestHeader("Authorization") final String authorization) {
        this.migrationService.updateAuthorInformation();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN')")
    @GetMapping(value = "/questions/migration-update-approvals")
    public ResponseEntity<?> migrateQuestionApproval(
            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
            @RequestHeader("Authorization") final String authorization) {
        List<Question> updatedQuestions = this.questionService.updateApprovals();
        log.info("Updated {} questions.", updatedQuestions.size());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN')")
    @GetMapping(value = "/questions/migration-update-content-type")
    public ResponseEntity<?> migrateQuestionType(
            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
            @RequestHeader("Authorization") final String authorization) {
        List<Question> updatedQuestions = this.questionService.updateContentType();
        log.info("Updated {} questions.", updatedQuestions.size());
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
