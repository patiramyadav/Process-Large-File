/**
 *
 */
package com.miyoz.qcollect.api.services.impl;

import com.miyoz.qcollect.api.exceptions.AlreadyExistsException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.repositories.UserRepository;
import com.miyoz.qcollect.api.services.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author Yogen
 */
@Service
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder;

    @Override
    public Optional<User> findOne(String id) {
        return Optional.ofNullable(this.userRepository.findOne(id));
    }

    @Override
    public User findUserByEmailAndPassword(String email, String password) {
        User user = this.userRepository.findByEmail(email);
        if (user == null || (user != null && !this.passwordEncoder.matches(password, user.getPassword()))) {
            log.error("User not found for provided email {}.", email);
            Error error = new Error(ErrorCodes.EXC404.toString(), "email", "Email or password not matched.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        return user;
    }

    @Override
    public List<User> findUserByRole(String role) {
        List<User> users = this.userRepository.findByRole(role);
        if (users == null || users.size() == 0) {
            log.error("User with provided {} Id does not exist.", role);
            Error error = new Error(ErrorCodes.EXC404.toString(), "role", "No user with role " + role);
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        return users;
    }

    @Override
    public User findUserByEmail(String email) {
        User userInDb = this.userRepository.findByEmail(email);
        if (userInDb == null) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "email", "No user with email found.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        return userInDb;
    }

    @Override
    public User updateUserWithPassword(User user) {
        User userInDb = this.userRepository.findByIdAndEmail(user.getId(), user.getEmail());
        if (userInDb == null) {
            log.error("Unable to update either Id {} or email {} already exist.", user.getId(), user.getEmail());
            throw new NotFoundException(ErrorCodes.EXC404.toString(), null);
        }
        return this.userRepository.save(user);
    }

    @Override
    public User findActiveEmailVerifiedTeacher(String id) {
        User userInDb = this.userRepository.findByIdAndEmailVerifiedAndActive(id, true, true);
        if (userInDb == null) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "userId", "No user with userId found.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        return userInDb;
    }

    @Override
    public List<User> findAll() {
        List<User> users = (List<User>) this.userRepository.findAll();
        if (users == null || users.size() == 0) {
            log.error("User List does not exist.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), null);
        }
        return users;
    }

    @Override
    public User create(User user) {
        User createdUser = this.userRepository.findByEmail(user.getEmail());
        if (createdUser != null) {
            log.error("User already exists for provided {}.", createdUser.getEmail());
            Error error = new Error(ErrorCodes.EXC409.toString(), "email", "User already exist with email " + user.getEmail());
            throw new AlreadyExistsException(ErrorCodes.EXC409.toString(), error);
        }
        return this.userRepository.save(user);
    }

    @Override
    public void delete(String userId) {
        User user = this.userRepository.findOne(userId);
        if (user == null) {
            log.error("User with id {} does not exist.", userId);
            Error error = new Error(ErrorCodes.EXC404.toString(), "id", "User not exist with Id: " + userId);
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        this.userRepository.delete(userId);
    }

    @Override
    public User update(User user) {
        User userInDb = this.userRepository.findByIdAndEmail(user.getId(), user.getEmail());
        if (userInDb == null) {
            log.error("Unable to update either Id {} or email {} already exist.", user.getId(), user.getEmail());
            throw new NotFoundException(ErrorCodes.EXC404.toString(), null);
        }
        user.setPassword(userInDb.getPassword());
        return this.userRepository.save(user);
    }

}
