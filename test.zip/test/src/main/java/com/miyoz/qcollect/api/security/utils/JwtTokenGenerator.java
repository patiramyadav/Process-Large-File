package com.miyoz.qcollect.api.security.utils;


import com.miyoz.qcollect.api.models.types.PlatformType;
import com.miyoz.qcollect.api.security.transfer.JwtUserDto;
import com.miyoz.qcollect.api.utils.Number;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.util.Date;

/**
 * @author Yogen
 */
public class JwtTokenGenerator {
    /**
     * Generates a JWT token containing username as subject, and userId and role as additional claims.
     * These properties are taken from the specified user object.
     * Tokens validity is infinite.
     *
     * @param u the user for which the token will be generated
     * @return the JWT token
     */
    public static String generateToken(JwtUserDto u, String secret, String platform) {
        final Date expirationDate;

        if (PlatformType.MOBILE.equals(platform)) {
            expirationDate = new Date(System.currentTimeMillis() + Number.HALF_MONTH);
        } else {
            expirationDate = new Date(System.currentTimeMillis() + Number.TWO_DAY);
        }

        //The JWT signature algorithm we will be using to sign the token
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

        //We will sign our JWT with our ApiKey secret
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secret);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

        Claims claims = Jwts.claims().setSubject(u.getUsername());
        claims.put("userId", u.getId() + "");
        claims.put("role", u.getRole());

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(new Date())
                .setExpiration(expirationDate)
                .signWith(signatureAlgorithm, signingKey)
                .compact();
    }
}
