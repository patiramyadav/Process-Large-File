/**
 *
 */
package com.miyoz.qcollect.api.services.impl;

import com.miyoz.qcollect.api.exceptions.AlreadyExistsException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Profile;
import com.miyoz.qcollect.api.repositories.ProfileRepository;
import com.miyoz.qcollect.api.services.ProfileService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
@Slf4j
public class ProfileServiceImpl implements ProfileService {

    private final ProfileRepository profileRepository;

    @Override
    public Optional<Profile> findOne(String id) {
        return Optional.ofNullable(this.profileRepository.findOne(id));
    }

    @Override
    public List<Profile> findAll() {
        //TODO
        return null;
    }

    @Override
    public Profile create(Profile profile) {
        Profile profileInDb = this.profileRepository.findByUserId(profile.getUserId());
        if (profileInDb != null) {
            log.error("Profile already exists with user id {}.", profileInDb.getUserId());
            Error error = new Error(ErrorCodes.EXC409.toString(), "id", "Profile already exist with user id " + profile.getUserId());
            throw new AlreadyExistsException(ErrorCodes.EXC409.toString(), error);
        }
        return this.profileRepository.save(profile);
    }

    @Override
    public void delete(String userId) {
        Profile profile = this.profileRepository.findByUserId(userId);
        if (profile == null) {
            log.error("Profile with userId {} does not exist.", userId);
            Error error = new Error(ErrorCodes.EXC404.toString(), "id", "Profile not exist with userId: " + userId);
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        profile.setActive(false);
        this.profileRepository.save(profile);
    }

    @Override
    public Profile update(Profile profile) {
        if (this.profileRepository.findOne(profile.getId()) == null) {
            log.error("Unable to update profile. Profile Id {} doesn't exist.", profile.getId());
            throw new NotFoundException(ErrorCodes.EXC404.toString(), null);
        }
        return this.profileRepository.save(profile);
    }

    @Override
    public Optional<Profile> findByUserId(String id) {
        return Optional.ofNullable(this.profileRepository.findByUserId(id));
    }
}
