package com.miyoz.qcollect.api.repositories;

import com.miyoz.qcollect.api.models.impl.Article;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;


public interface ArticleRepository extends MongoRepository<Article, String>, BaseRepository {
    @Query("{$and : [{ $text: { $search: ?0, $caseSensitive: false}}, {verified: true}]}")
    Page<Article> findByTitle(Pageable pageable, String title);

    @Query("{verified: ?0}")
    Page<Article> findAll(Pageable pageable, boolean verified);

    @Query("{ $text: { $search: ?0, $caseSensitive: ?1}}")
    List<Article> findByTitle(String title, boolean caseSensitive);

    @Query("{title: {'$regex':?0, '$options':'i'}}")
    List<Article> findByTitle(String title);

    @Query("{author.id: ?0 }")
    Page<Article> findByUserId(Pageable pageable, String userId);
}
