package com.miyoz.qcollect.api.services;

public interface MigrationService {
    void updateAuthorInformation();
}
