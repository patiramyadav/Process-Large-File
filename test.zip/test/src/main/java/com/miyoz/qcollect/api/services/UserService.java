/**
 *
 */
package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.User;

import java.util.List;

/**
 * @author Yogen
 */
public interface
UserService extends CommonService<String, User> {
    User findUserByEmailAndPassword(String email, String password);

    List<User> findUserByRole(String role);

    User findUserByEmail(String email);

    User updateUserWithPassword(User user);

    User findActiveEmailVerifiedTeacher(String id);
}
