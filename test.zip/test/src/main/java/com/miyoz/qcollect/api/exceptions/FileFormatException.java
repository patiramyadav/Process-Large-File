package com.miyoz.qcollect.api.exceptions;


import com.miyoz.qcollect.api.models.common.Error;
import lombok.Getter;

@Getter
public class FileFormatException extends BaseException {

    private static final long serialVersionUID = -4240564240662292632L;

    private final Error error;

    public FileFormatException(String message, Error error) {
        super(message);
        this.error = error;
    }
}
