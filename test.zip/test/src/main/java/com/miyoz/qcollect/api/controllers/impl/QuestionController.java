package com.miyoz.qcollect.api.controllers.impl;

import com.google.common.base.Strings;
import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.exceptions.InvalidInputException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Comment;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.interfaces.impl.QuestionResponse;
import com.miyoz.qcollect.api.models.interfaces.impl.SearchParams;
import com.miyoz.qcollect.api.security.models.AuthenticatedUser;
import com.miyoz.qcollect.api.services.CommentService;
import com.miyoz.qcollect.api.services.QuestionService;
import com.miyoz.qcollect.api.services.notification.OnAddSyllabusEvent;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class QuestionController implements BaseController<Question> {

    private final QuestionService questionService;

    private final CommentService commentService;

    private final ApplicationEventPublisher applicationEventPublisher;

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PostMapping(value = "/questions", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Question> createQuestion(@Valid @RequestBody Question question,
                                                   BindingResult result,
                                                   @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                   @RequestHeader("Authorization") final String authorization) {
        if (result.hasErrors()) {
            log.debug("Invalid question sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }
        Question savedQuestion = this.questionService.create(question);
        return new ResponseEntity<>(savedQuestion, HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @GetMapping(value = "/questions/{id}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<QuestionResponse> getQuestion(@PathVariable("id") String id,
                                                        @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                        @RequestHeader("Authorization") final String authorization) {
        return this.questionService.findOne(id).map(q -> {
            QuestionResponse questionResponse = new QuestionResponse(Arrays.asList(q));
            questionResponse.add(linkTo(methodOn(QuestionController.class).getQuestion(id, authorization)).withSelfRel());
            return new ResponseEntity<>(questionResponse, HttpStatus.OK);
        }).orElseThrow(() -> new NotFoundException(ErrorCodes.EXC404.toString(), null));
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @GetMapping(value = "/questions/duplicate", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> getQuestion(@ApiParam(value = "University", required = true)
                                         @RequestParam(value = "university") String university,
                                         @ApiParam(value = "Subject Name", required = true)
                                         @RequestParam(value = "subject") String subject,
                                         @ApiParam(value = "Course Faculty", required = true)
                                         @RequestParam(value = "faculty") String faculty,
                                         @ApiParam(value = "Post type", required = true)
                                         @RequestParam(value = "contentType") String contentType,
                                         @ApiParam(value = "Year", required = true)
                                         @RequestParam(value = "year") Integer year,
                                         @ApiParam(value = "program", required = true)
                                         @RequestParam(value = "program") String program,
                                         @ApiParam(value = "Semester", required = true)
                                         @RequestParam(value = "semester") String semester,
                                         @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                         @RequestHeader("Authorization") final String authorization) {
        SearchParams searchParams = SearchParams.builder().university(university).subject(subject)
                .contentType(contentType).year(year).program(program).semester(semester).build();
        Question question = this.questionService.findQuestion(searchParams);
        log.info("Duplicate does not exists.");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @GetMapping(value = "/questions", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Page<Question>> getQuestions(Pageable pageable,
                                                       @ApiParam(value = "Keyword to say for whom ex. me or all", required = false)
                                                       @RequestParam(value = "key", required = false) final String key,
                                                       @ApiParam(value = "Keyword to search for", required = false)
                                                       @RequestParam(value = "keyword", required = false) final String keyword,
                                                       @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                       @RequestHeader("Authorization") final String authorization) {
        log.info(pageable.toString());
        final Page<Question> questionPage;
        if ("me".equals(key)) {
            SecurityContext context = SecurityContextHolder.getContext();
            Authentication auth = context.getAuthentication();
            AuthenticatedUser authenticatedUser = ((AuthenticatedUser) auth.getPrincipal());
            if (Strings.isNullOrEmpty(keyword)) {
                questionPage = this.questionService.findAllForUser(pageable, authenticatedUser.getId());
            } else {
                questionPage = this.questionService.findAllForUser(pageable, authenticatedUser.getId(), keyword);
            }

        } else if ("all".equals(key)) {
            if (Strings.isNullOrEmpty(keyword)) {
                questionPage = this.questionService.findAll(pageable);
            } else {
                questionPage = this.questionService.findAll(pageable, keyword);
            }

        } else {
            throw new InvalidInputException(ErrorCodes.EXC400.toString(), new Error(ErrorCodes.EXC400.toString(), "key or level", "One of input required."));
        }
        return new ResponseEntity<>(questionPage, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PutMapping(value = "/questions", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<QuestionResponse> updateQuestion(@Valid @RequestBody Question question,
                                                           BindingResult result,
                                                           @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                           @RequestHeader("Authorization") final String authorization) {
        if (Strings.isNullOrEmpty(question.getId())) {
            result.rejectValue("id", "NotNull", "Id is required.");
        }
        if (result.hasErrors()) {
            log.debug("Invalid question sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }

        Question updatedQuestion = this.questionService.update(question);


        // send notification if question is approved
        if (!question.isVerified() && updatedQuestion.isVerified()) {
            this.applicationEventPublisher.publishEvent(new OnAddSyllabusEvent(updatedQuestion));
        }

        QuestionResponse questionResponse = new QuestionResponse(Collections.singletonList(updatedQuestion));
        questionResponse.add(linkTo(methodOn(QuestionController.class).updateQuestion(question, result, authorization)).withSelfRel());
        return new ResponseEntity<>(questionResponse, HttpStatus.OK);
    }

    @PutMapping(value = "/questions/{id}", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<QuestionResponse> updateQuestionLikeCount(@Valid @RequestBody Question question,
                                                                    BindingResult result,
                                                                    @PathVariable("id") String questionId,
                                                                    @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                                    @RequestHeader("Authorization") final String authorization) {

        if (Strings.isNullOrEmpty(question.getId())) {
            result.rejectValue("id", "NotNull", "Id is required.");
        }
        if (result.hasErrors()) {
            log.debug("Invalid question sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }

        return this.questionService.findOne(questionId).map(q -> {
            final int updatedLikeCount = q.getLikeCount() + 1;
            if (updatedLikeCount != question.getLikeCount()) {
                throw new DataException(ErrorCodes.EXC400.toString(), null);
            }
            q.setLikeCount(updatedLikeCount);
            this.questionService.updateQuestion(q);

            QuestionResponse questionResponse = new QuestionResponse(Collections.singletonList(q));
            questionResponse.add(linkTo(methodOn(QuestionController.class).updateQuestionLikeCount(question, result, questionId, authorization)).withSelfRel());
            return new ResponseEntity<>(questionResponse, HttpStatus.OK);
        }).orElseThrow(() -> new NotFoundException(ErrorCodes.EXC404.toString(), null));
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @DeleteMapping(value = "/questions/{id}", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> deleteQuestion(@ApiParam(value = "Question Id", required = true) @PathVariable("id") String id,
                                            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                            @RequestHeader("Authorization") final String authorization) {

        this.questionService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PostMapping(value = "/questions/{questionId}/comments", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Comment> createComment(@Valid @RequestBody Comment comment, BindingResult result,
                                                 @ApiParam(value = "Question Id", required = true)
                                                 @PathVariable("questionId") String questionId,
                                                 @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                 @RequestHeader("Authorization") final String authorization) {
        if (result.hasErrors()) {
            log.debug("Invalid question sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }
        Comment createdComment = this.commentService.create(comment);
        return new ResponseEntity<>(createdComment, HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PutMapping(value = "/questions/{questionId}/comments", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Comment> updateComment(@Valid @RequestBody Comment comment, BindingResult result,
                                                 @ApiParam(value = "Question Id", required = true)
                                                 @PathVariable("questionId") String questionId,
                                                 @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                 @RequestHeader("Authorization") final String authorization) {
        if (Strings.isNullOrEmpty(comment.getId())) {
            result.rejectValue("id", "NotNull", "Id is required.");
        }
        if (result.hasErrors()) {
            log.debug("Invalid question sent to server.");
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }

        Comment updatedComment = this.commentService.update(comment);
        return new ResponseEntity<>(updatedComment, HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @DeleteMapping("/questions/{questionId}/comments/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable("questionId") String questionId,
                                           @PathVariable("commentId") String commentId,
                                           @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                           @RequestHeader("Authorization") final String authorization) {
        if (!this.questionService.findOne(questionId).isPresent()) {
            throw new NotFoundException(ErrorCodes.EXC404.toString(), null);
        }

        this.commentService.delete(commentId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @GetMapping(value = "/questions/{id}/comments", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<List<Comment>> getComments(@ApiParam(value = "Question Id", required = true) @PathVariable("id") String questionId,
                                                     @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                     @RequestHeader("Authorization") final String authorization) {
        List<Comment> comments = this.commentService.findByQuestionId(questionId);
        return new ResponseEntity<>(comments, HttpStatus.OK);
    }
}
