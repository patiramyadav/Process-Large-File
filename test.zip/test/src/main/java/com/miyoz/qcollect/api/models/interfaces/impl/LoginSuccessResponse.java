package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.interfaces.BaseResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.hateoas.ResourceSupport;

@Getter
@AllArgsConstructor
public class LoginSuccessResponse extends ResourceSupport implements BaseResponse {

    private String userId;

    private String token;

    private String role;
}
