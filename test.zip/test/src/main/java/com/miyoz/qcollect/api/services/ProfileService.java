/**
 *
 */
package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.Profile;

import java.util.Optional;

public interface ProfileService extends CommonService<String, Profile> {
    Optional<Profile> findByUserId(String id);
}
