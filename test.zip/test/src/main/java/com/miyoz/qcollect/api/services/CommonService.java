package com.miyoz.qcollect.api.services;

import java.util.List;
import java.util.Optional;

/**
 * @author Yogen
 */
public interface CommonService<T, R> {
    Optional<R> findOne(T t);

    List<R> findAll();

    R create(R r);

    void delete(T t);

    R update(R r);
}
