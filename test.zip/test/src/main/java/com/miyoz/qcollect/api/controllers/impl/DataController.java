package com.miyoz.qcollect.api.controllers.impl;

import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.models.types.*;
import io.swagger.annotations.ApiParam;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@RestController
public class DataController implements BaseController {
    private static final Set<Class> KNOWN_ENUMERATOR_CLASSES = Stream.of(
            GenderType.class,
            LevelType.class,
            RoleType.class,
            ContentType.class,
            Semester.class,
            UniversityType.class,
            FacultyType.class,
            ProgramType.class
    ).collect(Collectors.toCollection(HashSet::new));

    private static final Map<String, Object> KNOWN_ENUMERATOR_VALUES;

    static {
        KNOWN_ENUMERATOR_VALUES = new HashMap<>();
        KNOWN_ENUMERATOR_CLASSES.forEach(knownEnum -> KNOWN_ENUMERATOR_VALUES.put(knownEnum.getSimpleName(), knownEnum.getEnumConstants()));
    }

    @GetMapping(value = "/data", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Map<String, Object> getAllDataValues(@ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                @RequestHeader("Authorization") final String authorization) {
        return KNOWN_ENUMERATOR_VALUES;
    }

}
