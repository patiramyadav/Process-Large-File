package com.miyoz.qcollect.api.controllers.impl;

import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.impl.UserToken;
import com.miyoz.qcollect.api.models.interfaces.impl.GenericResponse;
import com.miyoz.qcollect.api.models.interfaces.impl.PasswordResetRequest;
import com.miyoz.qcollect.api.models.types.PlatformType;
import com.miyoz.qcollect.api.services.EmailService;
import com.miyoz.qcollect.api.services.UserService;
import com.miyoz.qcollect.api.services.UserTokenService;
import com.miyoz.qcollect.api.utils.EmailConstructor;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class PasswordResetController implements BaseController<String> {
    @Value("${url.verify.password}")
    private String url;

    @Value("${jwt.secret}")
    private String secret;

    @Value("${email.body.passwordReset}")
    private String emailBody;

    @Value("${email.body.passwordResetWithCode}")
    private String emailBodyWithCode;

    @Value("${email.subject.passwordReset}")
    private String emailSubject;

    private final UserService userService;

    private final EmailService emailService;

    private final UserTokenService userTokenService;

    private final BCryptPasswordEncoder passwordEncoder;


    @PostMapping(value = "/user/resetPassword", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> resetPassword(@ApiParam(value = "Email for User", required = true) @RequestParam(value = "email") String email,
                                           @ApiParam(value = "Platform")
                                           @RequestHeader(value = "platform", required = false) String platform) {
        User user = this.userService.findUserByEmail(email);

        UserToken createdUserToken = this.userTokenService.createVerificationTokenForUser(EmailConstructor.createUserToken(user));

        final boolean isPlatformMobile = PlatformType.MOBILE.equals(platform);

        // if platform is mobile, set email body accordingly
        emailBody = isPlatformMobile ? emailBodyWithCode : emailBody;

        final String token = isPlatformMobile ? createdUserToken.getVerificationCode() : createdUserToken.getToken();

        try {
            this.emailService.sendEmail(EmailConstructor.setMailBody(url, token, user, emailBody, emailSubject), isPlatformMobile);
        } catch (Exception ex) {
            log.error("Sending email failed to {}", user.getEmail());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping(value = "/user/verifyResetToken", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> verifyPasswordResetToken(@ApiParam(value = "User ID", required = true) @RequestParam(value = "userId") String userId,
                                                      @ApiParam(value = "Token", required = true) @RequestParam(value = "token") String token) {
        UserToken userToken = this.userTokenService.findByUserIdAndToken(userId, token);

        this.userTokenService.deleteToken(userToken);

        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping(value = "/user/verifyResetPin", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<UserToken> verifyPasswordResetToken(@ApiParam(value = "PIN", required = true) @RequestHeader(value = "pin") String pin) {
        UserToken userToken = this.userTokenService.findByPin(pin);

        this.userTokenService.deleteToken(userToken);

        return new ResponseEntity<>(userToken, HttpStatus.OK);
    }

    @PutMapping(value = "/user/createPassword", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<GenericResponse> updatePassword(@RequestBody @Valid final PasswordResetRequest passwordResetRequest, BindingResult result) {
        if (passwordResetRequest.getPassword() != null && !passwordResetRequest.getPassword().equals(passwordResetRequest.getConfirmPassword())) {
            result.rejectValue("password", "Invalid", "Password didn't match.");
        }
        if (result.hasErrors()) {
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }
        return this.userService.findOne(passwordResetRequest.getUserId()).map(user -> {
            user.setPassword(this.passwordEncoder.encode(passwordResetRequest.getPassword()));
            this.userService.updateUserWithPassword(user);

            GenericResponse loginSuccessResponse = new GenericResponse();
            loginSuccessResponse.add(linkTo(methodOn(PasswordResetController.class).updatePassword(passwordResetRequest, result)).withSelfRel());
            return new ResponseEntity<>(loginSuccessResponse, HttpStatus.OK);
        }).orElseThrow(() -> new NotFoundException(ErrorCodes.EXC404.toString(), null));
    }
}
