package com.miyoz.qcollect.api.models.impl;

import com.miyoz.qcollect.api.models.Model;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

@AllArgsConstructor
@Getter
public class Author extends Model<String> {
    @NotNull
    @NotEmpty
    private String id;

    private String firstName;

    private String lastName;

    private String email;

    private String photoUrl;

}
