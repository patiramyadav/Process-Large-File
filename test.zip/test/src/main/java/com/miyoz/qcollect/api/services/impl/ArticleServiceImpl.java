/**
 *
 */
package com.miyoz.qcollect.api.services.impl;

import com.miyoz.qcollect.api.exceptions.AlreadyExistsException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Article;
import com.miyoz.qcollect.api.models.impl.Author;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.repositories.ArticleRepository;
import com.miyoz.qcollect.api.repositories.UserRepository;
import com.miyoz.qcollect.api.services.ArticleService;
import com.miyoz.qcollect.api.utils.QCollectAuth;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author Yogen
 */
@Service
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
@Slf4j
public class ArticleServiceImpl implements ArticleService {
    private final ArticleRepository articleRepository;

    private final UserRepository userRepository;


    @Override
    public Optional<Article> findOne(String id) {
        return Optional.ofNullable(this.articleRepository.findOne(id));
    }

    @Override
    public List<Article> findAll() {
        return null;
    }

    @Override
    public Article create(Article article) {
        List<Article> articlesInDb = this.articleRepository.findByTitle(article.getTitle());
        if (articlesInDb != null && articlesInDb.size() > 0) {
            log.error("Article already exists for provided title.");
            Error error = new Error(ErrorCodes.EXC409.toString(), "title", "Article already exists for provided title.");
            throw new AlreadyExistsException(ErrorCodes.EXC409.toString(), error);
        }
        User user = this.userRepository.findOne(article.getAuthor().getId());
        if (user == null) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "userId", "No user with userId found.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        Author author = new Author(user.getId(), user.getFirstName(), user.getLastName(), user.getEmail(), user.getPhotoUrl());
        article.setAuthor(author);

        return this.articleRepository.save(article);
    }

    @Override
    public void delete(String id) {

        Article article = this.articleRepository.findOne(id);

        if (article == null) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "articleId", "No article with articleId found.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }

        if (article.isVerified() && QCollectAuth.isRoleContributor()) {
            throw new AccessDeniedException("Access Denied!!");
        }

        this.articleRepository.delete(id);
    }

    @Override
    public Article update(Article article) {
        Article articleInDb = this.articleRepository.findOne(article.getId());
        if (articleInDb.isVerified() && QCollectAuth.isRoleContributor()) {
            throw new AccessDeniedException("Access Denied!!");
        }
        return this.articleRepository.save(article);
    }

    @Override
    public Page<Article> findAll(Pageable pageable) {
        return this.articleRepository.findAll(pageable);
    }

    @Override
    public Page<Article> findArticlesForUser(Pageable pageable, String userId) {
        return this.articleRepository.findByUserId(pageable, userId);
    }
}
