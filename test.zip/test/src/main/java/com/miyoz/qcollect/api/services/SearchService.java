package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.Article;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.interfaces.impl.SearchParams;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface SearchService {
    Page<Question> searchQuestions(Pageable pageable, SearchParams searchParams);

    Page<Article> searchArticles(Pageable pageable, String keyword);

    Page<Article> searchArticles(Pageable pageable);
}
