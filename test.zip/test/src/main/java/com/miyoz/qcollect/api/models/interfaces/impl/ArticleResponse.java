package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.impl.Article;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@Getter
@AllArgsConstructor
public class ArticleResponse extends ResourceSupport {
    private List<Article> articles;
}
