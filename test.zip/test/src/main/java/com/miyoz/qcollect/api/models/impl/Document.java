package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miyoz.qcollect.api.models.Model;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import org.springframework.data.annotation.Transient;
import org.springframework.web.multipart.MultipartFile;

@Getter
@AllArgsConstructor
@ToString
public class Document extends Model<String> {
    @Transient
    @JsonIgnore
    private String id;

    private String docName;

    private MultipartFile file;
}
