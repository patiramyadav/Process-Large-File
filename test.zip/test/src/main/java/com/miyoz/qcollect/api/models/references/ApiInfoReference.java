package com.miyoz.qcollect.api.models.references;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "api")
@Setter
@Getter
public class ApiInfoReference {
    private Map<String, String> info = new HashMap<>();

    public String getInfo(String key) {
        return this.info.get(key);
    }
}
