package com.miyoz.qcollect.api.repositories;

import com.miyoz.qcollect.api.models.impl.Profile;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProfileRepository extends MongoRepository<Profile, String>, BaseRepository {
    Profile findByUserId(String id);
}
