package com.miyoz.qcollect.api.services.impl;

import com.miyoz.qcollect.api.exceptions.AlreadyExistsException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Author;
import com.miyoz.qcollect.api.models.impl.Contribution;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.interfaces.impl.SearchParams;
import com.miyoz.qcollect.api.models.notifications.ApprovalNotification;
import com.miyoz.qcollect.api.models.types.ContentType;
import com.miyoz.qcollect.api.repositories.ContributionRepository;
import com.miyoz.qcollect.api.repositories.QuestionRepository;
import com.miyoz.qcollect.api.repositories.UserRepository;
import com.miyoz.qcollect.api.services.QuestionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.miyoz.qcollect.api.utils.QCollectAuth.getCurrentUser;
import static com.miyoz.qcollect.api.utils.QCollectAuth.isRoleContributor;


@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class QuestionServiceImpl implements QuestionService {
    private static final String CREATE = "create";
    private static final String DELETE = "delete";

    private final QuestionRepository questionRepository;

    private final ContributionRepository contributionRepository;

    private final UserRepository userRepository;

    @Override
    public Optional<Question> findOne(String id) {
        return Optional.ofNullable(this.questionRepository.findOne(id));
    }

    @Override
    public List<Question> findAll() {
        return this.questionRepository.findAll();
    }

    @Override
    public Question create(Question question) {
        Question questionInDb = this.questionRepository.findQuestion(
                question.getSubject(),
                question.getYear(),
                question.getSemester(),
                question.getUniversity(),
                question.getProgram(),
                question.getContentType()
        );
        if (Objects.nonNull(questionInDb)) {
            log.error("Question already exists with given info.");
            throw new AlreadyExistsException(ErrorCodes.EXC409.toString(), null);
        }

        question.setVerified(false);
        question.setDateCreated(new Date());

        User user = this.userRepository.findOne(question.getContributor().getId());
        if (user == null) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "userId", "No user with userId found.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        Author author = new Author(user.getId(), user.getFirstName(), user.getLastName(), user.getEmail(), user.getPhotoUrl());
        question.setContributor(author);

        Question questionSaved = this.questionRepository.save(question);

        //update contribution table
        updateContributionTable(questionSaved, CREATE);

        return questionSaved;
    }

    @Override
    public void delete(String id) {
        Question questionInDb = this.questionRepository.findOne(id);
        if (Objects.isNull(questionInDb)) {
            log.error("Question not found for provided id {}.", id);
            Error error = new Error(ErrorCodes.EXC404.toString(), "id", "Question not found.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }

        if (isRoleContributor() && questionInDb.isVerified()) {
            throw new AuthenticationServiceException("Unauthorized");
        }
        this.questionRepository.delete(id);

        //update contribution table
        updateContributionTable(questionInDb, DELETE);
    }

    @Override
    public Question update(Question question) {
        Question questionInDb = this.questionRepository.findOne(question.getId());
        if (Objects.isNull(questionInDb)) {
            log.error("Question not found for provided id {}.", question.getId());
            Error error = new Error(ErrorCodes.EXC404.toString(), "id", "Question not found.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }

        if (isRoleContributor() && questionInDb.isVerified()) {
            throw new AuthenticationServiceException("Unauthorized");
        }
        question.setDataModified(new Date());
        return this.questionRepository.save(question);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN')")
    @Override
    public Page<Question> findAll(Pageable pageable) {
        return this.questionRepository.findAll(pageable);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN')")
    @Override
    public Page<Question> findAll(Pageable pageable, String keyword) {
        return this.questionRepository.searchQuestions(pageable, keyword);
    }

    @Override
    public Page<Question> findAllForUser(Pageable pageable, String userId) {
        Contribution contribution = this.contributionRepository.findByUserId(userId);
        if (Objects.isNull(contribution) || contribution.getQuestionIds().isEmpty()) {
            Error error = new Error(ErrorCodes.EXC404.toString(), "userId", "No questions not found for user.");
            throw new NotFoundException(ErrorCodes.EXC404.toString(), error);
        }
        return this.questionRepository.findByIdIn(pageable, contribution.getQuestionIds());
    }

    @Override
    public Page<Question> findAllForUser(Pageable pageable, String userId, String keyword) {
        return this.questionRepository.searchQuestions(pageable, keyword, userId);
    }

    @Override
    public Page<Question> findAllForLevel(Pageable pageable, String level) {
        Sort sort = pageable.getSort();
        if (Objects.isNull(sort)) {
            sort = new Sort(Sort.Direction.DESC, "year");
        }
        Pageable pageableReq = new PageRequest(pageable.getPageNumber(), pageable.getPageSize(), sort);
        return this.questionRepository.findForLevel(pageableReq, level);
    }

    @Override
    public List<Question> updateApprovals() {
        List<Question> questions = this.questionRepository.findAll();
        List<Question> updatedQuestions = questions.stream().filter(question -> question.getApprovals() != null).map(question -> {
            question.setApprovals(new ArrayList<>());
            return question;
        }).collect(Collectors.toList());
        return this.questionRepository.save(updatedQuestions);
    }

    @Override
    public List<Question> updateContentType() {
        List<Question> questions = this.questionRepository.findAll();
        List<Question> updatedQuestions = questions.stream().filter(question -> question.getContentType() == null).map(question -> {
            question.setContentType(ContentType.QUESTION.toString());
            return question;
        }).collect(Collectors.toList());
        return this.questionRepository.save(updatedQuestions);
    }

    @Override
    public Question updateQuestion(Question question) {
        return this.questionRepository.save(question);
    }

    @Override
    public Question findQuestion(SearchParams searchParams) {
        Question question = this.questionRepository.findQuestion(searchParams.getSubject(),
                searchParams.getYear(), searchParams.getSemester(), searchParams.getUniversity(),
                searchParams.getProgram(), searchParams.getContentType());
        if (question != null) {
            log.error("Question already exists with given info.");
            throw new AlreadyExistsException(ErrorCodes.EXC409.toString(), null);
        }
        return question;
    }

    @Override
    public Page<ApprovalNotification> findApprovalsForUser(Pageable pageable, String userId) {
        Page<Question> questions = this.questionRepository.findByContributorId(pageable, userId);

        List<ApprovalNotification> approvals = questions.getContent()
                .stream()
                .map(q -> new ApprovalNotification(q.getSubject(), q.getLevel(), q.getDateCreated(),
                        q.getApprovals().isEmpty() ? null : q.getApprovals().get(q.getApprovals().size() - 1)))
                .collect(Collectors.toList());
        return new PageImpl<>(approvals, pageable, approvals.size());
    }

    private void updateContributionTable(Question question, String operation) {
        String currentUserId = getCurrentUser().getId();
        Contribution contribution = this.contributionRepository.findByUserId(currentUserId);
        List<String> savedQuestionIds = new ArrayList<>();
        if (Objects.isNull(contribution)) {
            contribution = new Contribution();
            contribution.setUserId(currentUserId);
        } else {
            savedQuestionIds = contribution.getQuestionIds();
        }
        if (CREATE.equals(operation)) {
            savedQuestionIds.add(question.getId());
        } else {
            savedQuestionIds.remove(question.getId());
        }

        contribution.setQuestionIds(savedQuestionIds);
        this.contributionRepository.save(contribution);
    }
}
