package com.miyoz.qcollect.api.models.impl;

import com.miyoz.qcollect.api.models.Model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;


@Getter
@Setter
@NoArgsConstructor
@ToString
@Document(collection = "user_token")
public class UserToken extends Model<String> {
    @Id
    private String id;

    private String token;

    private String verificationCode;

    private String userId;

    private Date expiryDate;
}
