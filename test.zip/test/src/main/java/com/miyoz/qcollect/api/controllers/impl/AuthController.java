package com.miyoz.qcollect.api.controllers.impl;

import com.google.common.base.Strings;
import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.exceptions.EmailNotVerifiedException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.interfaces.impl.LoginRequest;
import com.miyoz.qcollect.api.models.interfaces.impl.LoginSuccessResponse;
import com.miyoz.qcollect.api.models.interfaces.impl.UserRequest;
import com.miyoz.qcollect.api.models.types.PlatformType;
import com.miyoz.qcollect.api.models.types.RoleType;
import com.miyoz.qcollect.api.security.transfer.JwtUserDto;
import com.miyoz.qcollect.api.security.utils.JwtTokenGenerator;
import com.miyoz.qcollect.api.services.UserService;
import com.miyoz.qcollect.api.services.registration.OnRegistrationCompleteEvent;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Date;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class AuthController implements BaseController<LoginRequest> {

    @Value("${jwt.secret}")
    private String secret;

    private final UserService userService;
    private final ApplicationEventPublisher eventPublisher;
    private final BCryptPasswordEncoder passwordEncoder;

    @PostMapping(value = "/user/auth", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<LoginSuccessResponse> authorize(@Valid @RequestBody LoginRequest loginRequest,
                                                          BindingResult result,
                                                          @ApiParam(value = "Platform e.g. mobile, web")
                                                          @RequestHeader(value = "platform", required = false) String platform) {
        if (result.hasErrors()) {
            log.error("Login attempted with credentials: {}", loginRequest);
            throw new DataException(ErrorCodes.EXC400.toString(), result);
        }
        User userInDB = this.userService.findUserByEmailAndPassword(loginRequest.getEmail(), loginRequest.getPassword());

        if (!userInDB.isEmailVerified()) {
            Error error = new Error(ErrorCodes.EXC401.toString(), "email", "Email Not Verified.");
            throw new EmailNotVerifiedException(ErrorCodes.EXC401.toString(), error);
        }

        platform = !Strings.isNullOrEmpty(platform) && PlatformType.MOBILE.equals(platform)
                && RoleType.ROLE_VIEWER.toString().equals(userInDB.getRole()) ? PlatformType.MOBILE : PlatformType.WEB;

        if (platform.equals(PlatformType.WEB) && userInDB.getRole().equals(RoleType.ROLE_VIEWER.toString())) {
            throw new AccessDeniedException(ErrorCodes.EXC403.toString());
        }

        String token = JwtTokenGenerator.generateToken(
                new JwtUserDto(userInDB.getId(), loginRequest.getEmail(), userInDB.getRole()), secret, platform);

        log.debug("User with email: {} is authenticated.", loginRequest.getEmail());

        final LoginSuccessResponse loginSuccessResponse = new LoginSuccessResponse(userInDB.getId(), token, userInDB.getRole());
        loginSuccessResponse.add(linkTo(methodOn(AuthController.class).authorize(loginRequest, result, platform)).withSelfRel());
        return new ResponseEntity<>(loginSuccessResponse, HttpStatus.OK);
    }


    @PostMapping(value = "/user/signup", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> createUser(
            @ApiParam(value = "Request Body for User", required = true) @Valid @RequestBody UserRequest userRequest,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            throw new DataException(ErrorCodes.EXC400.toString(), bindingResult);
        }
        User user = getUserRequest(userRequest, false);
        User createdUser = this.userService.create(user);

        eventPublisher.publishEvent(new OnRegistrationCompleteEvent(createdUser));

        log.info("User with userId: {} is created.", createdUser.getEmail());
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PostMapping(value = "/user/social-signup", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<LoginSuccessResponse> createSocialUser(
            @ApiParam(value = "Request Body for User", required = true) @Valid @RequestBody UserRequest userRequest,
            BindingResult bindingResult,
            @ApiParam(value = "Platform e.g. mobile, web")
            @RequestHeader(value = "platform", required = false) String platform) {
        if (bindingResult.hasErrors()) {
            throw new DataException(ErrorCodes.EXC400.toString(), bindingResult);
        }
        User user = getUserRequest(userRequest, true);
        User createdUser = this.userService.create(user);
        log.info("User with userId: {} is created.", createdUser.getEmail());

        platform = !Strings.isNullOrEmpty(platform) && PlatformType.MOBILE.equals(platform)
                && RoleType.ROLE_VIEWER.equals(userRequest.getRole()) ? PlatformType.MOBILE : PlatformType.WEB;

        String token = JwtTokenGenerator.generateToken(
                new JwtUserDto(createdUser.getId(), createdUser.getEmail(), createdUser.getRole()), secret, platform);

        log.debug("User with email: {} is authenticated.", createdUser.getEmail());

        final LoginSuccessResponse loginSuccessResponse = new LoginSuccessResponse(createdUser.getId(), token, createdUser.getRole());
        loginSuccessResponse.add(linkTo(methodOn(AuthController.class).createSocialUser(userRequest, bindingResult, platform)).withSelfRel());

        return new ResponseEntity<>(loginSuccessResponse, HttpStatus.CREATED);
    }

    private User getUserRequest(UserRequest userRequest, boolean socialLogin) {
        return User.builder()
                .email(userRequest.getEmail())
                .firstName(userRequest.getFirstName())
                .lastName(userRequest.getLastName())
                .dateCreated(new Date())
                .password(this.passwordEncoder.encode(userRequest.getPassword()))
                .role(userRequest.getRole().toString())
                .emailVerified(socialLogin)
                .photoUrl(userRequest.getPhotoUrl())
                .active(socialLogin)
                .build();
    }
}
