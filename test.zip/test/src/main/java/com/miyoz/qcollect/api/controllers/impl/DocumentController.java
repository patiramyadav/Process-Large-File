package com.miyoz.qcollect.api.controllers.impl;

import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.exceptions.FileFormatException;
import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Document;
import com.miyoz.qcollect.api.models.impl.DocumentInfo;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.services.FileArchiveService;
import com.miyoz.qcollect.api.services.QuestionService;
import com.miyoz.qcollect.api.validators.fileValidator.FileValidator;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class DocumentController implements BaseController<Document> {

    private final FileArchiveService fileArchiveService;

    private final QuestionService questionService;

    private final FileValidator documentValidator;

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @PostMapping(value = "/documents", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DocumentInfo> uploadDocument(@RequestParam("file") MultipartFile file,
                                                       @RequestParam("docName") String docName,
                                                       @RequestParam("questionId") String questionId,
                                                       @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                       @RequestHeader("Authorization") final String authorization) {

        if (file.isEmpty()) {
            throw new DataException(ErrorCodes.EXC400.toString(), null);
        }
        Optional<Question> questionOptional = this.questionService.findOne(questionId);
        if (!questionOptional.isPresent()) {
            throw new NotFoundException(ErrorCodes.EXC404.toString(), new Error(ErrorCodes.EXC404.toString(), "userId", "No profile with input userId exists"));
        }
        if (!documentValidator.validate(file.getOriginalFilename())) {
            throw new FileFormatException(ErrorCodes.EXC400.toString(), new Error(ErrorCodes.EXC400.toString(), "fileExtension", "File Extension Not Matched.Please Select .JPG|.JPEG|.PNG|.PDF"));

        }
        Document document = new Document("id", docName, file);
        DocumentInfo documentInfo = this.fileArchiveService.saveFilesToS3(document);

        //update profile
        Question question = questionOptional.get();
        List<DocumentInfo> documentInfos = question.getDocuments().isEmpty() ? new ArrayList<>() : question.getDocuments();
        documentInfos.add(documentInfo);
        question.setDocuments(documentInfos);
        this.questionService.update(question);

        return new ResponseEntity<>(documentInfo, HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN') or hasRole('ROLE_CONTRIBUTOR')")
    @DeleteMapping(value = "/documents")
    public ResponseEntity<?> deleteDocument(@ApiParam(value = "S3 key for document", required = true)
                                            @RequestParam(value = "key") String s3key,
                                            @ApiParam(value = "Question ID", required = true)
                                            @RequestParam(value = "questionId") String questionId,
                                            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                            @RequestHeader("Authorization") final String authorization) {
        Optional<Question> questionOptional = this.questionService.findOne(questionId);
        if (!questionOptional.isPresent()) {
            throw new NotFoundException(ErrorCodes.EXC404.toString(), new Error(ErrorCodes.EXC404.toString(), "userId", "No profile with input userId exists"));
        }
        this.fileArchiveService.deleteFilesFromS3(s3key);

        //update question
        Question question = questionOptional.get();
        List<DocumentInfo> documentInfos = question.getDocuments().stream().filter(doc -> !s3key.equals(doc.getS3key())).collect(Collectors.toList());
        question.setDocuments(documentInfos);
        this.questionService.update(question);

        return new ResponseEntity<>(HttpStatus.OK);
    }
}
