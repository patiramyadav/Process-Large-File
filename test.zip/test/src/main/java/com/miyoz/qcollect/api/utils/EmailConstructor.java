package com.miyoz.qcollect.api.utils;


import com.miyoz.qcollect.api.models.impl.Email;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.impl.UserToken;
import org.apache.commons.lang.RandomStringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EmailConstructor {

    public static UserToken createUserToken(User user) {
        UserToken userToken = new UserToken();
        userToken.setToken(UUID.randomUUID().toString());
        userToken.setVerificationCode(RandomStringUtils.randomNumeric(Number.FOUR));
        userToken.setUserId(user.getId());
        userToken.setExpiryDate(new Date(System.currentTimeMillis() + Number.ONE_DAY));
        return userToken;
    }

    public static Email setMailBody(String url, String token, User user, String emailBody, String emailSubject) {

        if (token != null && token.length() == Number.FOUR) {
            url = token;
        } else if (token != null) {
            url = String.format("%s?id=%s&token=%s", url, user.getId(), token);
        }

        Email email = new Email();
        email.setFrom("support@miyozinc.com");
        email.setTo(user.getEmail());
        email.setSubject(emailSubject);


        Map<String, Object> model = new HashMap<>();
        model.put("firstname", user.getFirstName());
        model.put("lastname", user.getLastName());
        model.put("token", url);
        model.put("emailBody", emailBody);
        model.put("location", "Kathmandu,Nepal");
        model.put("signature", "http://qlocate.com/");
        email.setModel(model);
        return email;
    }

    public static Email setVerifiedMailBody(String url, User user, String emailBody, String emailSubject) {
        return setMailBody(url, null, user, emailBody, emailSubject);
    }

    public static Email setMobileMailBody(String verificationCode, User user, String emailBody, String emailSubject) {
        return setMailBody(null, verificationCode, user, emailBody, emailSubject);
    }
}
