package com.miyoz.qcollect.api.models.types;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class PlatformType {
    public static final String MOBILE = "mobile";
    public static final String WEB = "web";
}
