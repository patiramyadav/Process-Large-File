/**
 *
 */
package com.miyoz.qcollect.api.models.interfaces.impl;

import com.miyoz.qcollect.api.models.interfaces.BaseRequest;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import static com.miyoz.qcollect.api.utils.Number.SIX;
import static com.miyoz.qcollect.api.utils.Number.TEN;

/**
 * @author Yogen
 */
@Setter
@Getter
@ToString
public class PasswordChangeRequest implements BaseRequest {

    @NotEmpty
    @NotNull
    private String userId;

    @NotEmpty
    @NotNull
    private String email;

    @NotEmpty
    @NotNull
    @Size(min = SIX, max = TEN)
    private String oldPassword;

    @NotEmpty
    @NotNull
    @Size(min = SIX, max = TEN)
    private String password;

    @NotEmpty
    @NotNull
    private String confirmPassword;
}
