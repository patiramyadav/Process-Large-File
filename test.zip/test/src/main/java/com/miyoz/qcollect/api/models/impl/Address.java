package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miyoz.qcollect.api.models.Model;
import lombok.*;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.Transient;

import javax.validation.constraints.NotNull;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Address extends Model<String> {
    @JsonIgnore
    @Transient
    private String id;

    @NotEmpty
    @NotNull
    private String address1;
    private String address2;

    @NotEmpty
    @NotNull
    private String country;

    @NotEmpty
    @NotNull
    private String state;

    private String zip;

}
