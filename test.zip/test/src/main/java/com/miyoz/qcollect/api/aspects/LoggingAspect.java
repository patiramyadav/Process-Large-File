package com.miyoz.qcollect.api.aspects;


import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import org.springframework.stereotype.Component;


@Slf4j
@Component
@Aspect
public class LoggingAspect {

    @Pointcut("within(com.miyoz.qcollect.api.controllers..*)")
    public void logControllerMethods() {
        // intentionally left blank
    }

    @Pointcut("within(com.miyoz.qcollect.api.services..*)")
    public void logServiceMethods() {
        // intentionally left blank
    }

    @Pointcut("within(com.miyoz.qcollect.api.repositories..*)")
    public void logRepositoryMethods() {
        // intentionally left blank
    }

    @Pointcut("within(com.miyoz.qcollect.api.clients..*)")
    public void logClientMethods() {
        // intentionally left blank
    }

    @Pointcut("within(com.miyoz.qcollect.api.utils..*)")
    public void logUtilsMethods() {
        // intentionally left blank
    }

    @Around("logControllerMethods() || logServiceMethods() || logRepositoryMethods() || logClientMethods() || logUtilsMethods()")
    public Object logMethodCalls(ProceedingJoinPoint joinpoint) throws Throwable {
        log.trace("{} >> {}()", joinpoint.getTarget().getClass().getSimpleName(), joinpoint.getSignature().getName());
        Object result = joinpoint.proceed();
        log.trace("{} << {}()", joinpoint.getTarget().getClass().getSimpleName(), joinpoint.getSignature().getName());
        return result;
    }
}
