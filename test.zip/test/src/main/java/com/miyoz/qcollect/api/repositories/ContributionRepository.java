package com.miyoz.qcollect.api.repositories;

import com.miyoz.qcollect.api.models.impl.Contribution;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ContributionRepository extends MongoRepository<Contribution, String> {
    Contribution findByUserId(String userId);
}
