package com.miyoz.qcollect.api.services.impl;

import com.miyoz.qcollect.api.exceptions.NotFoundException;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Comment;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.models.types.RoleType;
import com.miyoz.qcollect.api.repositories.CommentRepository;
import com.miyoz.qcollect.api.repositories.UserRepository;
import com.miyoz.qcollect.api.security.models.AuthenticatedUser;
import com.miyoz.qcollect.api.services.CommentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Created by Yogen on 11/22/2017.
 */
@Service
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class CommentServiceImpl implements CommentService {
    private final CommentRepository commentRepository;

    private final UserRepository userRepository;

    @Override
    public Optional<Comment> findOne(String id) {
        return null;
    }

    @Override
    public List<Comment> findAll() {
        return null;
    }

    @Override
    public Comment create(Comment comment) {
        AuthenticatedUser currentUser = getCurrentUser();
        User user = this.userRepository.findOne(currentUser.getId());

        comment.setCommenterName(user.getFirstName() + " " + user.getLastName());
        comment.setDateCreated(new Date());
        return this.commentRepository.save(comment);
    }

    @Override
    public void delete(String id) {
        final Comment comment = this.commentRepository.findOne(id);
        if (Objects.isNull(comment)) {
            throw new NotFoundException(ErrorCodes.EXC404.toString(), null);
        }
        AuthenticatedUser currentUser = getCurrentUser();
        User user = this.userRepository.findOne(currentUser.getId());

        if (!(user.getFirstName() + " " + user.getLastName()).equals(comment.getCommenterName())) {
            throw new AccessDeniedException("Access Denied!!");
        }
        this.commentRepository.delete(id);
    }

    @Override
    public Comment update(Comment comment) {
        AuthenticatedUser currentUser = getCurrentUser();
        User user = this.userRepository.findOne(currentUser.getId());

        if (!(user.getFirstName() + " " + user.getLastName()).equals(comment.getCommenterName())) {
            throw new AccessDeniedException("Access Denied!!");
        }
        return this.commentRepository.save(comment);
    }

    private AuthenticatedUser getCurrentUser() {
        //check if role is ok
        SecurityContext context = SecurityContextHolder.getContext();
        Authentication auth = context.getAuthentication();
        return (AuthenticatedUser) auth.getPrincipal();
    }

    @Override
    public List<Comment> findByQuestionId(String questionId) {
        List<Comment> comments = this.commentRepository.findByQuestionId(questionId);
        AuthenticatedUser currentUser = getCurrentUser();
        User user = this.userRepository.findOne(currentUser.getId());

        if (!RoleType.ROLE_ADMIN.toString().equals(user.getRole())) {
            boolean validUser = false;

            for (Comment comment : comments) {
                if (comment.getCommenterName().equals(user.getFirstName() + " " + user.getLastName())) {
                    validUser = true;
                    break;
                }
            }
            if (!validUser && !comments.isEmpty()) {
                throw new AccessDeniedException("Access Denied!!!");
            }
        }
        return comments;
    }
}
