package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.UserToken;


public interface UserTokenService {
    UserToken createVerificationTokenForUser(UserToken userToken);

    UserToken findByUserIdAndToken(String userId, String token);

    UserToken findByUserId(String userId);

    UserToken findByPin(String userId);

    void deleteToken(UserToken userToken);
}
