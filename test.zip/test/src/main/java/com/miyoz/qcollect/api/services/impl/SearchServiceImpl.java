package com.miyoz.qcollect.api.services.impl;

import com.google.common.base.Strings;
import com.miyoz.qcollect.api.models.impl.Article;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.interfaces.impl.SearchParams;
import com.miyoz.qcollect.api.repositories.ArticleRepository;
import com.miyoz.qcollect.api.repositories.QuestionRepository;
import com.miyoz.qcollect.api.services.SearchService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static com.miyoz.qcollect.api.models.types.LevelType.*;


@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class SearchServiceImpl implements SearchService {
    private final QuestionRepository questionRepository;

    private final ArticleRepository articleRepository;

    @Override
    public Page<Question> searchQuestions(Pageable pageable, SearchParams searchParams) {
        final Page<Question> questions;

        // return search results if keyword is provided
        if (!Strings.isNullOrEmpty(searchParams.getKeyword())) {
            return this.questionRepository.searchQuestions(pageable, searchParams.getKeyword());
        }

        if (Objects.nonNull(searchParams.getLevel())) {
            String level = searchParams.getLevel();
            Integer year = searchParams.getYear();
            String course = searchParams.getSubject();
            if (SCHOOL.toString().equals(level)) {
                if (year != null && Objects.nonNull(course)) {
                    questions = this.questionRepository.findForSchool(pageable, level, year, course);
                } else if (year != null) {
                    questions = this.questionRepository.findForSchool(pageable, level, year);
                } else {
                    questions = this.questionRepository.findForSchool(pageable, level);
                }
            } else if (PLUS_ONE.toString().equals(level) || PLUS_TWO.toString().equals(level)) {
                String faculty = searchParams.getFaculty();
                if (year != null && !Strings.isNullOrEmpty(course)) {
                    questions = this.questionRepository.findForInter(pageable, level, faculty, year, course);
                } else if (year != null) {
                    questions = this.questionRepository.findForInter(pageable, level, faculty, year);
                } else {
                    questions = this.questionRepository.findForInter(pageable, level, faculty);
                }
            } else {
                String university = searchParams.getUniversity();
                String program = searchParams.getProgram();
                String semester = searchParams.getSemester();
                if (Objects.nonNull(year) && Objects.nonNull(course)) {
                    questions = this.questionRepository.findForCollege(pageable, level, university, program, semester, year, course);
                } else if (Objects.nonNull(year)) {
                    questions = this.questionRepository.findForCollege(pageable, level, university, program, semester, year);
                } else if (Objects.nonNull(course)) {
                    questions = this.questionRepository.findForCollegeByCourse(pageable, level, university, program, semester, course);
                } else {
                    questions = this.questionRepository.findForCollege(pageable, level, university, program, semester);
                }
            }
        } else {
            questions = this.questionRepository.findByCourseName(pageable, searchParams.getSubject());
        }
        return questions;
    }

    @Override
    public Page<Article> searchArticles(Pageable pageable, String keyword) {
        return this.articleRepository.findByTitle(pageable, keyword);
    }

    @Override
    public Page<Article> searchArticles(Pageable pageable) {
        Sort sort = pageable.getSort();
        if (Objects.isNull(sort)) {
            sort = new Sort(Sort.Direction.DESC, "dateCreated");
        }
        pageable = new PageRequest(pageable.getPageNumber(), pageable.getPageSize(), sort);
        return this.articleRepository.findAll(pageable, true);
    }
}
