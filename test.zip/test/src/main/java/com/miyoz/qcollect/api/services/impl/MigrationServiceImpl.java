package com.miyoz.qcollect.api.services.impl;

import com.miyoz.qcollect.api.models.impl.Author;
import com.miyoz.qcollect.api.models.impl.Contribution;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.impl.User;
import com.miyoz.qcollect.api.repositories.ContributionRepository;
import com.miyoz.qcollect.api.repositories.QuestionRepository;
import com.miyoz.qcollect.api.repositories.UserRepository;
import com.miyoz.qcollect.api.services.MigrationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
@Slf4j
public class MigrationServiceImpl implements MigrationService {
    private final ContributionRepository contributionRepository;

    private final QuestionRepository questionRepository;

    private final UserRepository userRepository;

    @Override
    public void updateAuthorInformation() {
        List<Contribution> contributions = this.contributionRepository.findAll();

        contributions.forEach(contribution -> {
            User contributor = this.userRepository.findOne(contribution.getUserId());
            Author author = new Author(contributor.getId(), contributor.getFirstName(), contributor.getLastName(),
                    contributor.getEmail(), contributor.getPhotoUrl());
            List<Question> questions = this.questionRepository.findByIdIn(contribution.getQuestionIds());
            List<Question> updatedQuestions = questions.stream().map(question -> {
                question.setContributor(author);
                return question;
            }).collect(Collectors.toList());
            List<Question> savedQuestions = questionRepository.save(updatedQuestions);
            log.info("Updated {} questions for {}", savedQuestions.size(), author.getEmail());
        });
    }
}
