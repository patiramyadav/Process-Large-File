package com.miyoz.qcollect.api.models.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.miyoz.qcollect.api.models.Model;
import lombok.Data;
import org.springframework.data.annotation.Transient;

import java.util.Date;

/**
 * Created by Yogen on 12/3/2017.
 */
@Data
public class Approval extends Model<String> {
    @JsonIgnore
    @Transient
    private String id;

    private String approverName;

    private String approverEmail;

    private Date approvalDate = new Date();

    private boolean approved;
}
