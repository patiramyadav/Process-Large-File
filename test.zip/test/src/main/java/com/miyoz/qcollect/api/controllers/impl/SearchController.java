package com.miyoz.qcollect.api.controllers.impl;

import com.google.common.base.Strings;
import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.exceptions.InvalidInputException;
import com.miyoz.qcollect.api.models.common.Error;
import com.miyoz.qcollect.api.models.common.ErrorCodes;
import com.miyoz.qcollect.api.models.impl.Article;
import com.miyoz.qcollect.api.models.impl.Message;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.interfaces.impl.SearchParams;
import com.miyoz.qcollect.api.services.SearchService;
import com.miyoz.qcollect.api.validators.SearchParamValidator;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class SearchController implements BaseController<Message> {

    private final SearchService searchService;

    private final SearchParamValidator searchParamValidator;

    @GetMapping(value = "/questions/search", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Page<Question>> searchQuestions(Pageable pageable,
                                                          @ApiParam(value = "Keyword")
                                                          @RequestParam(value = "keyword", required = false) String keyword,
                                                          @ApiParam(value = "University")
                                                          @RequestParam(value = "university", required = false) String university,
                                                          @ApiParam(value = "Subject Name")
                                                          @RequestParam(value = "subject", required = false) String subject,
                                                          @ApiParam(value = "Course Faculty")
                                                          @RequestParam(value = "faculty", required = false) String faculty,
                                                          @ApiParam(value = "Course Level")
                                                          @RequestParam(value = "level", required = false) String level,
                                                          @ApiParam(value = "Year")
                                                          @RequestParam(value = "year", required = false) Integer year,
                                                          @ApiParam(value = "program")
                                                          @RequestParam(value = "program", required = false) String program,
                                                          @ApiParam(value = "Semester")
                                                          @RequestParam(value = "semester", required = false) String semester,
                                                          @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                          @RequestHeader("Authorization") final String authorization) {
        final SearchParams searchParams = SearchParams.builder().keyword(keyword).university(university).subject(subject).faculty(faculty)
                .year(year).level(level).program(program).semester(semester).build();

        if (!this.searchParamValidator.validateSearchParam(searchParams)) {
            throw new InvalidInputException(ErrorCodes.EXC400.toString(),
                    new Error("EXC400", "requestParam", "Invalid input combination."));
        }

        Page<Question> questions = this.searchService.searchQuestions(pageable, searchParams);
        return new ResponseEntity<>(questions, HttpStatus.OK);
    }

    @GetMapping(value = "/articles/search", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Page<Article>> searchArticles(Pageable pageable,
                                                        @ApiParam(value = "keyword") @RequestParam(value = "keyword", required = false) String keyword,
                                                        @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                        @RequestHeader("Authorization") final String authorization) {
        final Page<Article> articles;

        if (Strings.isNullOrEmpty(keyword)) {
            articles = this.searchService.searchArticles(pageable);
        } else {
            articles = this.searchService.searchArticles(pageable, keyword);
        }
        return new ResponseEntity<>(articles, HttpStatus.OK);
    }
}
