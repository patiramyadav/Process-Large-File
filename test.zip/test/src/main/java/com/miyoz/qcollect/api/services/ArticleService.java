/**
 *
 */
package com.miyoz.qcollect.api.services;

import com.miyoz.qcollect.api.models.impl.Article;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ArticleService extends CommonService<String, Article> {
    Page<Article> findAll(Pageable pageable);
    Page<Article> findArticlesForUser(Pageable pageable, String userId);
}
