package com.miyoz.qcollect.api.models.notifications;

import com.miyoz.qcollect.api.models.impl.Approval;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Date;

@AllArgsConstructor
@Getter
public class ApprovalNotification {
    private String subject;

    private String level;

    private Date dateCreated;

    private Approval approval;
}
