package com.miyoz.qcollect.api.models.dtos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.miyoz.qcollect.api.models.impl.Address;
import com.miyoz.qcollect.api.models.impl.Coordinate;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.List;

@Setter
@Getter
@ToString
@JsonInclude(Include.NON_NULL)
public class UserDto {
    private String id;

    private String firstName;

    private String lastName;

    private String email;

    private Date dateCreated;

    private boolean active;

    private boolean emailVerified;

    private String role;

    private Address address;
    private Coordinate eqvtCoordinate;

    private List<String> expertise;

    private String photoUrl;
}
