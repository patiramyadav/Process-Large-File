package com.miyoz.qcollect.api.models.types;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.models.common.ErrorCodes;

/**
 * Created by Yogen on 10/28/2017.
 */
public enum UniversityType {
    TU("Tribhuwan University"),
    POKHARA_UNIVERSITY("Pokhara University"),
    PURWANCHAL_UNIVERSITY("Purwanchal University"),
    KATHMANDU_UNIVERSITY("Kathmandu University"),
    HSEB("HSEB"),
    SSE("SSE");

    private final String value;

    UniversityType(String value) {
        this.value = value;
    }

    @JsonCreator
    public static UniversityType forValue(final String value) {
        for (UniversityType universityType : values()) {
            if (universityType.value.equalsIgnoreCase(value)) {
                return universityType;
            }
        }
        throw new DataException(ErrorCodes.EXC400.toString(), null);
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }
}
