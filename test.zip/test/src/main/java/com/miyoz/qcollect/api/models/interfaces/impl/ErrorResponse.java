package com.miyoz.qcollect.api.models.interfaces.impl;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.miyoz.qcollect.api.models.interfaces.BaseResponse;
import com.miyoz.qcollect.api.models.common.Error;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorResponse implements BaseResponse {
    private int code;
    private String developersMessage;
    private List<Error> errors;
}
