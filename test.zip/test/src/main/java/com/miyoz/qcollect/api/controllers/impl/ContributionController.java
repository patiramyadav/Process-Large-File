package com.miyoz.qcollect.api.controllers.impl;

import com.miyoz.qcollect.api.controllers.BaseController;
import com.miyoz.qcollect.api.models.impl.Question;
import com.miyoz.qcollect.api.models.notifications.ApprovalNotification;
import com.miyoz.qcollect.api.services.QuestionService;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
@RestController
public class ContributionController implements BaseController<Question> {
    private final QuestionService questionService;

    @PreAuthorize("hasRole('ROLE_SUPER_ADMIN') or hasRole('ROLE_ADMIN')")
    @GetMapping(value = "/users/{id}/contributions", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Page<Question>> getQuestions(Pageable pageable,
                                                       @ApiParam(value = "User Id", required = true) @PathVariable("id") String id,
                                                       @ApiParam(value = "Token with format 'Bearer Token'", required = true)
                                                       @RequestHeader("Authorization") final String authorization) {
        Page<Question> questions = this.questionService.findAllForUser(pageable, id);

        for (Question question : questions) {
            question.setContent(null);
            question.setApprovals(null);
            question.setDocuments(null);
        }
        return new ResponseEntity<>(questions, HttpStatus.OK);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/users/{id}/approvals", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Page<ApprovalNotification>> getApprovals(
            Pageable pageable,
            @ApiParam(value = "User Id", required = true) @PathVariable("id") String userId,
            @ApiParam(value = "Token with format 'Bearer Token'", required = true)
            @RequestHeader("Authorization") final String authorization) {

        Page<ApprovalNotification> approvalNotifications = this.questionService.findApprovalsForUser(pageable, userId);

        return new ResponseEntity<>(approvalNotifications, HttpStatus.OK);
    }
}
