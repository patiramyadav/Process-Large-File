package com.miyoz.qcollect.api.validators;

import com.google.common.base.Strings;
import com.miyoz.qcollect.api.models.interfaces.impl.SearchParams;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.miyoz.qcollect.api.models.types.LevelType.PLUS_ONE;
import static com.miyoz.qcollect.api.models.types.LevelType.PLUS_TWO;
import static com.miyoz.qcollect.api.models.types.UniversityType.SSE;

/**
 * Created by Yogen on 10/28/2017.
 */
@Component
@Slf4j
public class SearchParamValidator {
    public boolean validateSearchParam(SearchParams searchParams) {
        if (!Strings.isNullOrEmpty(searchParams.getKeyword())) {
            return true;
        }
        String level = searchParams.getLevel();
        String program = searchParams.getProgram();
        Integer year = searchParams.getYear();
        String university = searchParams.getUniversity();
        String semester = searchParams.getSemester();
        String faculty = searchParams.getFaculty();

        if (PLUS_ONE.toString().equals(level) || PLUS_TWO.toString().equals(level)) {
            return !Strings.isNullOrEmpty(faculty);
        } else if (!SSE.toString().equals(level)) {
            return !Strings.isNullOrEmpty(university) && !Strings.isNullOrEmpty(program) && !Strings.isNullOrEmpty(semester);
        } else {
            return true;
        }
    }
}
