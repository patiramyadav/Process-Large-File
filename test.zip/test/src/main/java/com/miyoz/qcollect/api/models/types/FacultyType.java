package com.miyoz.qcollect.api.models.types;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.miyoz.qcollect.api.exceptions.DataException;
import com.miyoz.qcollect.api.models.common.ErrorCodes;

/**
 * Created by Yogen on 10/28/2017.
 */
public enum FacultyType {
    SCHOOL("SSE"),
    SCIENCE("Science"),
    MANAGEMENT("Management"),
    ARTS("Arts"),
    HUMANITIES("Humanities"),
    SOCIAL_WORK("Social Work"),
    ENGINEERING("Enginnering"),
    MEDICINE("Medical"),
    LAW("Law"),
    NURSING("Nursing");

    private final String value;

    FacultyType(String value) {
        this.value = value;
    }

    @JsonCreator
    public static FacultyType forValue(final String value) {
        for (FacultyType levelType : values()) {
            if (levelType.value.equalsIgnoreCase(value)) {
                return levelType;
            }
        }
        throw new DataException(ErrorCodes.EXC400.toString(), null);
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }
}
