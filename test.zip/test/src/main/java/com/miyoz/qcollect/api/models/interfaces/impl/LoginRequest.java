/**
 *
 */
package com.miyoz.qcollect.api.models.interfaces.impl;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import com.miyoz.qcollect.api.models.interfaces.BaseRequest;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Yogen
 */
@Setter
@Getter
@ToString
public class LoginRequest implements BaseRequest {

    @NotEmpty
    @Email
    private String email;

    @NotEmpty
    private String password;
}
